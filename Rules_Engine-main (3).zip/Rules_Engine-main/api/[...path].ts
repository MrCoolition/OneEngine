import type { VercelRequest, VercelResponse } from '@vercel/node';
import ExcelJS from 'exceljs';
import { DEFAULT_DAF_PARSED_WORKBOOK } from './_shared/daf-seed.js';
import {
  buildRuleCatalog,
  bucketForRow,
  CATALOG_COMPILER_VERSION,
  catalogSnapshot,
  executeRow,
  executeRows,
  summarizeBatch
} from './_shared/engine.js';
import type { JsonValue, Predicate, RouteManifest, RowExecutionResult, RuleAction, RuleDefinition, RuleImportReport, RuleRun, WorkflowRow } from './_shared/types.js';
import { createWorkflowRow } from './_shared/normalize.js';
import { DEFAULT_DAF_FILE, DEFAULT_SOURCE_FILE, loadWorkbookFile, parseDafWorkbook, parseSourceWorkbook, workbookExists } from './_shared/workbooks.js';
import { getStore, newId } from './_shared/store.js';
import { hasDatabaseUrl } from './_shared/db.js';

type PredicateOperator = Extract<Predicate, { field: string }>['op'];

const ALLOWED_FILTER_FIELDS = new Map<string, string>([
  ['business_key', 'Business'],
  ['request_type_key', 'Request type'],
  ['vendor_lc', 'Vendor'],
  ['din_lc', 'DIN'],
  ['min_lc', 'MIN'],
  ['manufacturer_lc', 'Manufacturer'],
  ['brand_lc', 'Brand'],
  ['description_lc', 'Description'],
  ['parent_category_lc', 'Parent category'],
  ['subcategory_lc', 'Sub category'],
  ['usage_num', 'Usage'],
  ['meets_criteria_num', 'Meets criteria'],
  ['current_action_key', 'Current ACTION'],
  ['current_buysmart_key', 'Current BuySmart action'],
  ['is_compass', 'Compass USA'],
  ['is_canada', 'Compass Canada'],
  ['is_healthtrust', 'HealthTrust'],
  ['is_hmshost', 'HMSHost'],
  ['is_prf', 'PRF'],
  ['is_sorf', 'SORF'],
  ['is_srf', 'SRF'],
  ['is_one_time', 'One-time request'],
  ['is_permanent', 'Permanent request'],
  ['is_pantry', 'Pantry/APL'],
  ['is_in_catalog', 'In catalog']
]);

const ALLOWED_OPERATORS = new Set<PredicateOperator>([
  'eq',
  'ne',
  'in',
  'not_in',
  'contains',
  'not_contains',
  'blank',
  'not_blank',
  'gt',
  'ge',
  'lt',
  'le',
  'is_true',
  'is_false'
]);

const NO_VALUE_OPERATORS = new Set<string>(['blank', 'not_blank', 'is_true', 'is_false']);
const NUMERIC_OPERATORS = new Set<string>(['gt', 'ge', 'lt', 'le']);
const OPERATOR_LABELS = new Map<string, string>([
  ['eq', 'equals'],
  ['ne', 'does not equal'],
  ['in', 'is in'],
  ['not_in', 'is not in'],
  ['contains', 'contains'],
  ['not_contains', 'does not contain'],
  ['blank', 'is blank'],
  ['not_blank', 'is not blank'],
  ['gt', '>'],
  ['ge', '>='],
  ['lt', '<'],
  ['le', '<='],
  ['is_true', 'is true'],
  ['is_false', 'is false']
]);

const manifest: RouteManifest = {
  frontendRoutes: [
    { path: '/', label: 'Compliance Rules', purpose: 'Rules readiness, recent batches, and processing entry point.' },
    { path: '/upload', label: 'Process PRF', purpose: 'Upload a PRF/SORF/SRF workbook, run saved rules, and show result buckets.' },
    { path: '/execute', label: 'Execution Console', purpose: 'Optional run console for selected batches.' },
    { path: '/workbench', label: 'Analyst Workbench', purpose: 'Search, filter, review, and edit workflow row decisions.' },
    { path: '/reports', label: 'Buckets', purpose: 'Compliance bucket rollups, drilldowns, coverage, CSV/XLSX export, and manual-format export.' },
    { path: '/rules', label: 'Rule Catalog', purpose: 'Browse the saved compliance rule catalog.' },
    { path: '/settings', label: 'System', purpose: 'Current operating status and workflow links.' }
  ],
  apiRoutes: [
    { method: 'GET', path: '/api/health', purpose: 'Rule engine status and saved rule readiness.' },
    { method: 'GET', path: '/api/routes', purpose: 'Frontend and API route manifest.' },
    { method: 'POST', path: '/api/bootstrap', purpose: 'Admin maintenance for storage tables and saved rules.' },
    { method: 'GET', path: '/api/batches', purpose: 'List source batches.' },
    { method: 'POST', path: '/api/batches/upload', purpose: 'Upload a PRF/SORF/SRF workbook as base64 JSON.' },
    { method: 'POST', path: '/api/batches/sample', purpose: 'Local-only sample ingestion when a workspace workbook exists.' },
    { method: 'GET', path: '/api/batches/:batchId', purpose: 'Batch metadata and KPI summary.' },
    { method: 'DELETE', path: '/api/batches/:batchId', purpose: 'Archive a batch.' },
    { method: 'GET', path: '/api/batches/:batchId/rows', purpose: 'Paginated/filterable workflow rows.' },
    { method: 'GET', path: '/api/batches/:batchId/summary', purpose: 'Batch KPI, compliance buckets, and chart-ready summary.' },
    { method: 'POST', path: '/api/batches/:batchId/export', purpose: 'Export CSV, audit XLSX, or manual-format XLSX outcomes.' },
    { method: 'PATCH', path: '/api/rows/:rowId', purpose: 'Patch analyst-editable row fields with audit.' },
    { method: 'GET', path: '/api/rules', purpose: 'List saved rule definitions in execution priority order and seed the DAF catalog if empty.' },
    { method: 'POST', path: '/api/rules', purpose: 'Create a user-managed compliance rule with optional execution priority.' },
    { method: 'PATCH', path: '/api/rules/:ruleId', purpose: 'Enable, disable, or update a saved rule, including execution priority.' },
    { method: 'DELETE', path: '/api/rules/:ruleId', purpose: 'Archive a user-managed rule.' },
    { method: 'POST', path: '/api/rules/seed', purpose: 'Admin refresh for the bundled DAF-derived rule catalog.' },
    { method: 'POST', path: '/api/rules/import-daf', purpose: 'Admin-only rule catalog import override. Normal processing uses saved rules.' },
    { method: 'GET', path: '/api/rules/:ruleId', purpose: 'Rule details, version, and variants.' },
    { method: 'POST', path: '/api/rules/:ruleId/versions', purpose: 'Create a draft version from the current rule.' },
    { method: 'PATCH', path: '/api/rules/versions/:versionId', purpose: 'Edit draft/ready version metadata and variants.' },
    { method: 'POST', path: '/api/rules/versions/:versionId/approve', purpose: 'Approve a rule version for execution.' },
    { method: 'POST', path: '/api/rules/variants/:variantId/test', purpose: 'Test one variant against a row or raw sample without persisting.' },
    { method: 'POST', path: '/api/rules/simulate', purpose: 'Run rules against one row without persisting.' },
    { method: 'POST', path: '/api/runs', purpose: 'Execute approved rule variants against a batch.' },
    { method: 'GET', path: '/api/runs/:runId', purpose: 'Run metadata and counts.' },
    { method: 'GET', path: '/api/runs/:runId/results', purpose: 'Row-level before/after execution trace results.' }
  ]
};

export default async function handler(req: VercelRequest, res: VercelResponse): Promise<void> {
  setCommonHeaders(res);
  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  const path = getPath(req);
  const store = getStore();

  try {
    if (req.method === 'GET' && pathEquals(path, 'health')) {
      const seededCatalog = await getSeededRuleCatalog(store);
      sendJson(res, 200, {
        ok: true,
        store: store.kind,
        databaseConfigured: hasDatabaseUrl(),
        defaultDafWorkbook: await workbookExists(DEFAULT_DAF_FILE),
        defaultSourceWorkbook: await workbookExists(DEFAULT_SOURCE_FILE),
        rulesSeeded: seededCatalog.seeded,
        ruleCount: seededCatalog.rules.length,
        executableVariantCount: seededCatalog.report.executableVariants,
        timestamp: new Date().toISOString()
      });
      return;
    }

    if (req.method === 'GET' && pathEquals(path, 'routes')) {
      sendJson(res, 200, manifest);
      return;
    }

    if (req.method === 'POST' && pathEquals(path, 'bootstrap')) {
      const result = await store.bootstrap();
      const seededCatalog = await getSeededRuleCatalog(store);
      const payload = {
        ...result,
        rulesSeeded: seededCatalog.seeded,
        ruleCount: seededCatalog.rules.length,
        executableVariantCount: seededCatalog.report.executableVariants
      };
      await store.audit('schema.bootstrap', 'system', null, payload);
      sendJson(res, 200, payload);
      return;
    }

    if (req.method === 'GET' && pathEquals(path, 'batches')) {
      sendJson(res, 200, { batches: await store.listBatches() });
      return;
    }

    if (req.method === 'POST' && pathEquals(path, 'batches', 'upload')) {
      const body = await readJson(req);
      const fileName = stringBody(body['fileName']) || 'upload.xlsx';
      const fileBase64 = stringBody(body['fileBase64']);
      if (!fileBase64) throw httpError(400, 'fileBase64 is required.');
      const parsed = await parseSourceWorkbook(fileName, base64ToBuffer(fileBase64));
      const batch = await store.createBatch(parsed, {
        name: stringBody(body['name']) || fileName,
        reportingDate: stringBody(body['reportingDate']) || today(),
        sourceKind: 'upload'
      });
      await store.audit('batch.uploaded', 'source_batch', batch.id, { fileName, rowCount: parsed.rows.length });
      sendJson(res, 200, { batchId: batch.id, rowCount: batch.rowCount, sourceSheetName: batch.sourceSheetName, columns: parsed.columns, warnings: parsed.warnings });
      return;
    }

    if (req.method === 'POST' && pathEquals(path, 'batches', 'sample')) {
      const body = await readJson(req, true);
      const buffer = await loadWorkbookFile(DEFAULT_SOURCE_FILE);
      const parsed = await parseSourceWorkbook(DEFAULT_SOURCE_FILE, buffer);
      const batch = await store.createBatch(parsed, {
        name: stringBody(body['name']) || 'Standard PRF/SORF/SRF sample',
        reportingDate: stringBody(body['reportingDate']) || today(),
        sourceKind: 'sample'
      });
      sendJson(res, 200, { batchId: batch.id, rowCount: batch.rowCount, sourceSheetName: batch.sourceSheetName, columns: parsed.columns, warnings: parsed.warnings });
      return;
    }

    if (path[0] === 'batches' && path[1] && path.length === 2 && req.method === 'GET') {
      const batch = await store.getBatch(path[1]);
      if (!batch) throw httpError(404, 'Batch not found.');
      sendJson(res, 200, { batch });
      return;
    }

    if (path[0] === 'batches' && path[1] && path.length === 2 && req.method === 'DELETE') {
      sendJson(res, 200, { archived: await store.archiveBatch(path[1]) });
      return;
    }

    if (path[0] === 'batches' && path[1] && path[2] === 'rows' && req.method === 'GET') {
      sendJson(res, 200, await store.listRows(path[1], getUrl(req).searchParams));
      return;
    }

    if (path[0] === 'batches' && path[1] && path[2] === 'summary' && req.method === 'GET') {
      const rows = await store.getRows(path[1]);
      sendJson(res, 200, summarizeBatch(rows));
      return;
    }

    if (path[0] === 'batches' && path[1] && path[2] === 'export' && req.method === 'POST') {
      const body = await readJson(req, true);
      const format = (stringBody(body['format']) || 'csv').toLowerCase();
      const rows = await store.getRows(path[1]);
      const priorityLookup = rulePriorityLookup((await getSeededRuleCatalog(store)).rules);
      if (format === 'manual' || format === 'manual-xlsx') {
        const buffer = await exportManualXlsx(rows);
        sendFile(res, 200, buffer, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', `rules-engine-manual-${path[1]}.xlsx`);
      } else if (format === 'xlsx') {
        const buffer = await exportXlsx(rows, priorityLookup);
        sendFile(res, 200, buffer, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', `rules-engine-${path[1]}.xlsx`);
      } else {
        const csv = exportCsv(rows, priorityLookup);
        sendFile(res, 200, Buffer.from(csv, 'utf8'), 'text/csv; charset=utf-8', `rules-engine-${path[1]}.csv`);
      }
      await store.audit('batch.exported', 'source_batch', path[1], { format });
      return;
    }

    if (path[0] === 'rows' && path[1] && req.method === 'PATCH') {
      const row = await store.updateRow(path[1], await readJson(req));
      if (!row) throw httpError(404, 'Row not found.');
      sendJson(res, 200, { row });
      return;
    }

    if (req.method === 'GET' && pathEquals(path, 'rules')) {
      const seededCatalog = await getSeededRuleCatalog(store);
      sendJson(res, 200, seededCatalog);
      return;
    }

    if (req.method === 'POST' && pathEquals(path, 'rules')) {
      const seededCatalog = await getSeededRuleCatalog(store);
      const rule = createUserRule(await readJson(req), seededCatalog.rules);
      await store.replaceRuleCatalog([...seededCatalog.rules, rule]);
      await store.audit('rule.created', 'rule_definition', rule.id, { ruleId: rule.ruleId, name: rule.name });
      sendJson(res, 201, { rule, rules: await store.listRules() });
      return;
    }

    if (req.method === 'POST' && pathEquals(path, 'rules', 'seed')) {
      const body = await readJson(req, true);
      const seededCatalog = await getSeededRuleCatalog(store, Boolean(body['force']));
      sendJson(res, 200, seededCatalog);
      return;
    }

    if (req.method === 'POST' && pathEquals(path, 'rules', 'import-daf')) {
      const body = await readJson(req, true);
      const fileName = stringBody(body['fileName']) || DEFAULT_DAF_FILE;
      const parsed = body['fileBase64']
        ? await parseDafWorkbook(fileName, base64ToBuffer(stringBody(body['fileBase64'])))
        : DEFAULT_DAF_PARSED_WORKBOOK;
      const { rules, report } = buildRuleCatalog(parsed);
      await store.replaceRuleCatalog(rules);
      sendJson(res, 200, { report, rules });
      return;
    }

    if (path[0] === 'rules' && path[1] && path.length === 2 && req.method === 'PATCH') {
      const body = await readJson(req);
      const rules = await store.listRules();
      const index = rules.findIndex((item) => item.ruleId === path[1]);
      if (index < 0) throw httpError(404, 'Rule not found.');
      const rule = rules[index];
      if (hasRuleEditPayload(body)) {
        rules[index] = updateRuleFromBody(rule, body);
      } else if (body['executionPriority'] !== undefined) {
        rules[index] = setRulePriority(rule, priorityFromBody(body['executionPriority'], [], rule.variants[0]?.executionPriority));
      } else if (body['enabled'] !== undefined) {
        rules[index] = setRuleEnabled(rule, Boolean(body['enabled']));
      } else {
        throw httpError(400, 'Send rule fields or enabled status to update.');
      }
      await store.replaceRuleCatalog(rules);
      await store.audit('rule.updated', 'rule_definition', rule.id, { ruleId: rule.ruleId, fields: Object.keys(body) });
      sendJson(res, 200, { rule: rules[index], rules: await store.listRules() });
      return;
    }

    if (path[0] === 'rules' && path[1] && path.length === 2 && req.method === 'DELETE') {
      if (isBundledRuleId(path[1])) throw httpError(409, 'Bundled rules can be disabled, but not removed.');
      const rules = await store.listRules();
      const rule = rules.find((item) => item.ruleId === path[1]);
      if (!rule) throw httpError(404, 'Rule not found.');
      await store.replaceRuleCatalog(rules.filter((item) => item.ruleId !== path[1]));
      await store.audit('rule.archived', 'rule_definition', rule.id, { ruleId: rule.ruleId });
      sendJson(res, 200, { archived: true, rules: await store.listRules() });
      return;
    }

    if (path[0] === 'rules' && path[1] && path[2] === 'versions' && path.length === 3 && req.method === 'POST') {
      const rules = await store.listRules();
      const rule = rules.find((item) => item.ruleId === path[1]);
      if (!rule) throw httpError(404, 'Rule not found.');
      const draftVersionId = newId();
      rule.versionId = draftVersionId;
      rule.versionNumber += 1;
      rule.status = 'draft';
      rule.automationLevel = 'guided';
      rule.updatedAt = new Date().toISOString();
      rule.variants = rule.variants.map((variant, index) => ({
        ...variant,
        id: newId(),
        ruleVersionId: draftVersionId,
        runtimeRuleId: `${rule.ruleId}.${String(index + 1).padStart(2, '0')}`,
        status: 'draft',
        enabled: false
      }));
      await store.replaceRuleCatalog(rules);
      await store.audit('rule.version.created', 'rule_definition', rule.id, { ruleId: rule.ruleId, versionId: draftVersionId });
      sendJson(res, 200, { rule });
      return;
    }

    if (path[0] === 'rules' && path[1] === 'versions' && path[2] && path.length === 3 && req.method === 'PATCH') {
      const body = await readJson(req);
      const rules = await store.listRules();
      const rule = rules.find((item) => item.versionId === path[2]);
      if (!rule) throw httpError(404, 'Rule version not found.');
      if (body['status']) rule.status = stringBody(body['status']) as typeof rule.status;
      if (body['automationLevel']) rule.automationLevel = stringBody(body['automationLevel']) as typeof rule.automationLevel;
      if (body['notes']) rule.notes = stringBody(body['notes']);
      if (Array.isArray(body['variants'])) {
        const variantsById = new Map(rule.variants.map((variant) => [variant.id, variant]));
        for (const patch of body['variants'] as Record<string, unknown>[]) {
          const variant = variantsById.get(stringBody(patch['id']));
          if (!variant) continue;
          if (patch['enabled'] !== undefined) variant.enabled = Boolean(patch['enabled']);
          if (patch['status']) variant.status = stringBody(patch['status']) as typeof variant.status;
          if (patch['predicateJson'] !== undefined) variant.predicateJson = patch['predicateJson'] as typeof variant.predicateJson;
          if (patch['actionJson'] !== undefined) variant.actionJson = patch['actionJson'] as typeof variant.actionJson;
          if (patch['description']) variant.description = stringBody(patch['description']);
          if (patch['executionPriority'] !== undefined) variant.executionPriority = priorityFromBody(patch['executionPriority'], [], variant.executionPriority);
        }
      }
      rule.updatedAt = new Date().toISOString();
      await store.replaceRuleCatalog(rules);
      await store.audit('rule.version.updated', 'rule_version', path[2], { fields: Object.keys(body) });
      sendJson(res, 200, { rule });
      return;
    }

    if (path[0] === 'rules' && path[1] === 'versions' && path[2] && path[3] === 'approve' && req.method === 'POST') {
      const rules = await store.listRules();
      const rule = rules.find((item) => item.versionId === path[2]);
      if (!rule) throw httpError(404, 'Rule version not found.');
      rule.status = 'approved';
      rule.variants = rule.variants.map((variant) => ({
        ...variant,
        status: variant.isExecutable ? 'approved' : 'ready',
        enabled: variant.isExecutable
      }));
      rule.updatedAt = new Date().toISOString();
      await store.replaceRuleCatalog(rules);
      await store.audit('rule.version.approved', 'rule_version', path[2], { ruleId: rule.ruleId });
      sendJson(res, 200, { rule });
      return;
    }

    if (path[0] === 'rules' && path[1] === 'variants' && path[2] && path[3] === 'test' && req.method === 'POST') {
      const body = await readJson(req);
      const rules = await store.listRules();
      const variant = rules.flatMap((rule) => rule.variants).find((item) => item.id === path[2] || item.runtimeRuleId === path[2]);
      if (!variant) throw httpError(404, 'Rule variant not found.');
      const row = await rowFromRequestBody(store, body);
      const executableVariant = { ...variant, enabled: true, isExecutable: true, status: 'approved' as const };
      sendJson(res, 200, { before: row, after: executeRow(row, [executableVariant]) });
      return;
    }

    if (path[0] === 'rules' && path[1] && path.length === 2 && req.method === 'GET') {
      const rule = await store.getRule(path[1]);
      if (!rule) throw httpError(404, 'Rule not found.');
      sendJson(res, 200, { rule });
      return;
    }

    if (req.method === 'POST' && pathEquals(path, 'rules', 'simulate')) {
      const body = await readJson(req);
      const rules = await store.listRules();
      const row = await rowFromRequestBody(store, body);
      const variants = rules.flatMap((rule) => rule.variants).filter((variant) => variant.enabled && variant.isExecutable && variant.status === 'approved');
      sendJson(res, 200, { before: row, after: executeRow(row, variants) });
      return;
    }

    if (req.method === 'POST' && pathEquals(path, 'runs')) {
      const body = await readJson(req);
      const batchId = stringBody(body['batchId']);
      if (!batchId) throw httpError(400, 'batchId is required.');
      const rowIds = Array.isArray(body['rowIds']) ? body['rowIds'].map(String) : undefined;
      const dryRun = Boolean(body['dryRun']);
      const beforeRows = await store.getRows(batchId);
      const { rules } = await getSeededRuleCatalog(store);
      const executableRuleCount = rules.flatMap((rule) => rule.variants).filter((variant) => variant.enabled && variant.isExecutable && variant.status === 'approved').length;
      if (executableRuleCount === 0) {
        throw httpError(409, 'No runnable rules are loaded.');
      }
      const executed = executeRows(beforeRows, rules, rowIds);
      const run = createRuleRun(batchId, stringBody(body['mode']) || 'full_batch', beforeRows.length, executed.changedCount, executed.reviewCount, catalogSnapshot(rules));
      const results = createResults(run.id, beforeRows, executed.rows, rowIds);
      if (!dryRun) await store.createRun(run, results, executed.rows);
      sendJson(res, 200, { run, results: results.slice(0, 50), dryRun });
      return;
    }

    if (path[0] === 'runs' && path[1] && path.length === 2 && req.method === 'GET') {
      const run = await store.getRun(path[1]);
      if (!run) throw httpError(404, 'Run not found.');
      sendJson(res, 200, { run });
      return;
    }

    if (path[0] === 'runs' && path[1] && path[2] === 'results' && req.method === 'GET') {
      sendJson(res, 200, { results: await store.listRunResults(path[1]) });
      return;
    }

    throw httpError(404, `No route for ${req.method} /api/${path.join('/')}`);
  } catch (error) {
    const status = typeof error === 'object' && error && 'statusCode' in error ? Number((error as { statusCode: number }).statusCode) : 500;
    const message = error instanceof Error ? error.message : 'Unexpected error.';
    sendJson(res, status, { ok: false, error: message });
  }
}

async function rowFromRequestBody(store: ReturnType<typeof getStore>, body: Record<string, unknown>): Promise<WorkflowRow> {
  if (body['batchId'] && body['rowId']) {
    const rows = await store.getRows(stringBody(body['batchId']));
    const row = rows.find((item) => item.id === body['rowId']);
    if (row) return row;
  }
  if (body['rawRow'] && typeof body['rawRow'] === 'object') {
    return createWorkflowRow('simulation', body['rawRow'] as Record<string, JsonValue>, 1, new Date().toISOString(), newId);
  }
  throw httpError(400, 'Provide batchId + rowId or rawRow.');
}

async function getSeededRuleCatalog(
  store: ReturnType<typeof getStore>,
  force = false
): Promise<{ rules: RuleDefinition[]; report: RuleImportReport; seeded: boolean }> {
  if (force) await store.bootstrap();
  const existingRules = await listRulesWithSchemaRepair(store);
  if (!force && existingRules.length > 0 && !catalogNeedsRefresh(existingRules)) {
    return { rules: existingRules, report: reportFromRules(existingRules), seeded: false };
  }

  if (!force) await store.bootstrap();
  const { rules, report } = buildRuleCatalog(DEFAULT_DAF_PARSED_WORKBOOK);
  const mergedRules = [...rules, ...customRulesFrom(existingRules)];
  try {
    await store.replaceRuleCatalog(mergedRules);
    await store.audit('rules.seeded', 'rule_catalog', null, {
      source: DEFAULT_DAF_PARSED_WORKBOOK.fileName,
      force,
      ruleCount: mergedRules.length,
      executableVariantCount: reportFromRules(mergedRules).executableVariants
    });
    return { rules: mergedRules, report: reportFromRules(mergedRules), seeded: true };
  } catch (error) {
    const recoveredRules = await store.listRules().catch(() => []);
    if (recoveredRules.length > 0) return { rules: recoveredRules, report: reportFromRules(recoveredRules), seeded: false };
    throw error;
  }
}

function catalogNeedsRefresh(rules: RuleDefinition[]): boolean {
  const bundledRules = rules.filter((rule) => isBundledRuleId(rule.ruleId));
  const variants = bundledRules.flatMap((rule) => rule.variants);
  if (bundledRules.length !== bundledRuleIds().size || variants.length === 0) return true;
  return variants.some((variant) => variant.source.compiledLogic?.compilerVersion !== CATALOG_COMPILER_VERSION);
}

function customRulesFrom(rules: RuleDefinition[]): RuleDefinition[] {
  return rules.filter((rule) => !isBundledRuleId(rule.ruleId));
}

function isBundledRuleId(ruleId: string): boolean {
  return bundledRuleIds().has(ruleId);
}

function bundledRuleIds(): Set<string> {
  return new Set(DEFAULT_DAF_PARSED_WORKBOOK.logicRows.map((row) => row.ruleId));
}

async function listRulesWithSchemaRepair(store: ReturnType<typeof getStore>): Promise<RuleDefinition[]> {
  try {
    return await store.listRules();
  } catch {
    await store.bootstrap();
    return store.listRules();
  }
}

function reportFromRules(rules: RuleDefinition[]): RuleImportReport {
  const variants = rules.flatMap((rule) => rule.variants);
  return {
    created: 0,
    updated: 0,
    unchanged: rules.length,
    warnings: [],
    duplicateRuleIds: [],
    sheetNames: DEFAULT_DAF_PARSED_WORKBOOK.sheetNames,
    executableVariants: variants.filter((variant) => variant.enabled && variant.isExecutable && variant.status === 'approved').length,
    guidedVariants: variants.filter((variant) => variant.automationLevel === 'guided').length,
    manualVariants: variants.filter((variant) => variant.automationLevel === 'manual' || variant.automationLevel === 'future').length
  };
}

function createUserRule(body: Record<string, unknown>, existingRules: RuleDefinition[]): RuleDefinition {
  const ruleId = cleanRuleId(stringBody(body['ruleId'])) || nextUserRuleId(existingRules);
  if (existingRules.some((rule) => rule.ruleId === ruleId)) throw httpError(409, `Rule ${ruleId} already exists.`);

  const name = stringBody(body['name']).trim();
  if (!name) throw httpError(400, 'Rule name is required.');

  const actionBody = recordBody(body['actions']);
  const filters = filtersFromBody(body);
  const predicate = predicateFromFilters(filters, stringBody(body['filterJoin']));
  const actions = actionsFromRequest(actionBody, body['actionItems']);
  const sourceActions = sourceActionFields(actions);
  const now = new Date().toISOString();
  const enabled = body['enabled'] !== false;
  const definitionId = newId();
  const versionId = newId();
  const variantId = newId();
  const requestTypes = requestTypesFromBody(body['requestTypes']);
  const fieldFilterLogic = filterLogicTextForFilters(filters, stringBody(body['filterJoin']));
  const aggregateLogic = aggregateLogicText(actions);
  const executionPriority = priorityFromBody(body['executionPriority'], existingRules);

  return {
    id: definitionId,
    ruleId,
    name,
    ruleGroup: stringBody(body['ruleGroup']).trim() || 'User Managed',
    businessScope: stringBody(body['businessScope']).trim() || 'All',
    requestTypes,
    discoveryReference: 'Created in Compliance Rules',
    notes: stringBody(body['notes']).trim(),
    ownerTeam: 'Compliance Operations',
    versionId,
    versionNumber: 1,
    status: enabled ? 'approved' : 'disabled',
    automationLevel: 'alpha',
    variants: [
      {
        id: variantId,
        ruleDefinitionId: definitionId,
        ruleVersionId: versionId,
        ruleId,
        runtimeRuleId: `${ruleId}.01`,
        runtimeKind: 'row_rule',
        executionPriority,
        enabled,
        isExecutable: true,
        stopProcessing: Boolean(body['stopProcessing']),
        predicateJson: predicate,
        actionJson: actions,
        description: fieldFilterLogic,
        automationLevel: 'alpha',
        status: enabled ? 'approved' : 'disabled',
        source: {
          ruleId,
          ruleGroup: stringBody(body['ruleGroup']).trim() || 'User Managed',
          business: stringBody(body['businessScope']).trim() || 'All',
          requestTypes: requestTypes.join(', '),
          executionPriority,
          decisionCriteria: fieldFilterLogic,
          action: sourceActions.action,
          ifInStockAction: sourceActions.ifInStockAction,
          buysmartAction: sourceActions.buysmartAction,
          dailyActionFileColumns: '',
          setAction: aggregateLogic,
          downstreamHandling: sourceActions.note,
          discoveryReference: 'Created in Compliance Rules',
          notes: stringBody(body['notes']),
          sourceRowNumber: 0,
          fieldFilterLogic,
          aggregateLogic,
          logic: `${fieldFilterLogic} => ${aggregateLogic}`,
          compiledLogic: {
            compilerVersion: CATALOG_COMPILER_VERSION,
            fieldFilterLogic,
            aggregateLogic,
            predicateJson: predicate,
            actionJson: actions,
            executable: true,
            warnings: []
          }
        }
      }
    ],
    createdAt: now,
    updatedAt: now
  };
}

function hasRuleEditPayload(body: Record<string, unknown>): boolean {
  return ['name', 'ruleGroup', 'businessScope', 'requestTypes', 'filter', 'filters', 'filterJoin', 'actions', 'actionItems', 'stopProcessing', 'notes'].some(
    (field) => body[field] !== undefined
  );
}

function updateRuleFromBody(rule: RuleDefinition, body: Record<string, unknown>): RuleDefinition {
  const requestedRuleId = cleanRuleId(stringBody(body['ruleId']));
  if (requestedRuleId && requestedRuleId !== rule.ruleId) throw httpError(400, 'Rule ID cannot be changed. Create a new rule for a new ID.');

  const name = stringBody(body['name']).trim();
  if (!name) throw httpError(400, 'Rule name is required.');
  if (rule.variants.length === 0) throw httpError(400, 'This rule has no editable variant.');

  const actionBody = recordBody(body['actions']);
  const filters = filtersFromBody(body);
  const predicate = predicateFromFilters(filters, stringBody(body['filterJoin']));
  const actions = actionsFromRequest(actionBody, body['actionItems']);
  const sourceActions = sourceActionFields(actions);
  const now = new Date().toISOString();
  const enabled = body['enabled'] !== undefined ? Boolean(body['enabled']) : rule.status !== 'disabled';
  const requestTypes = requestTypesFromBody(body['requestTypes']);
  const fieldFilterLogic = filterLogicTextForFilters(filters, stringBody(body['filterJoin']));
  const aggregateLogic = aggregateLogicText(actions);
  const ruleGroup = stringBody(body['ruleGroup']).trim() || rule.ruleGroup || 'User Managed';
  const businessScope = stringBody(body['businessScope']).trim() || rule.businessScope || 'All';
  const notes = stringBody(body['notes']).trim();
  const primaryVariant = rule.variants[0];
  const variantStatus = enabled ? 'approved' : 'disabled';
  const executionPriority = priorityFromBody(body['executionPriority'], [], primaryVariant.executionPriority);

  return {
    ...rule,
    name,
    ruleGroup,
    businessScope,
    requestTypes,
    notes,
    status: enabled ? 'approved' : 'disabled',
    automationLevel: 'alpha',
    updatedAt: now,
    variants: rule.variants.map((variant, index) => {
      if (index !== 0) {
        return enabled
          ? variant
          : {
              ...variant,
              enabled: false,
              status: 'disabled'
            };
      }
      return {
        ...primaryVariant,
        enabled,
        isExecutable: true,
        executionPriority,
        stopProcessing: Boolean(body['stopProcessing']),
        predicateJson: predicate,
        actionJson: actions,
        description: fieldFilterLogic,
        automationLevel: 'alpha',
        status: variantStatus,
        source: {
          ...primaryVariant.source,
          ruleId: rule.ruleId,
          ruleGroup,
          business: businessScope,
          requestTypes: requestTypes.join(', '),
          executionPriority,
          decisionCriteria: fieldFilterLogic,
          action: sourceActions.action,
          ifInStockAction: sourceActions.ifInStockAction,
          buysmartAction: sourceActions.buysmartAction,
          setAction: aggregateLogic,
          downstreamHandling: sourceActions.note,
          notes,
          fieldFilterLogic,
          aggregateLogic,
          logic: `${fieldFilterLogic} => ${aggregateLogic}`,
          compiledLogic: {
            compilerVersion: CATALOG_COMPILER_VERSION,
            fieldFilterLogic,
            aggregateLogic,
            predicateJson: predicate,
            actionJson: actions,
            executable: true,
            warnings: []
          }
        }
      };
    })
  };
}

function setRuleEnabled(rule: RuleDefinition, enabled: boolean): RuleDefinition {
  const now = new Date().toISOString();
  const hasExecutableVariant = rule.variants.some((variant) => variant.isExecutable);
  const status = enabled ? (hasExecutableVariant ? 'approved' : 'ready') : 'disabled';
  return {
    ...rule,
    status,
    updatedAt: now,
    variants: rule.variants.map((variant) => ({
      ...variant,
      enabled: enabled && variant.isExecutable,
      status: enabled ? (variant.isExecutable ? 'approved' : 'ready') : 'disabled'
    }))
  };
}

function setRulePriority(rule: RuleDefinition, executionPriority: number): RuleDefinition {
  const now = new Date().toISOString();
  return {
    ...rule,
    updatedAt: now,
    variants: rule.variants.map((variant) => ({
      ...variant,
      executionPriority,
      source: {
        ...variant.source,
        executionPriority
      }
    }))
  };
}

function predicateFromFilter(filter: Record<string, unknown>): Predicate {
  const field = stringBody(filter['field']).trim();
  const opText = stringBody(filter['op']).trim();
  if (!ALLOWED_FILTER_FIELDS.has(field)) throw httpError(400, 'Choose a supported filter field.');
  if (!ALLOWED_OPERATORS.has(opText as PredicateOperator)) throw httpError(400, 'Choose a supported filter operator.');

  const op = opText as PredicateOperator;
  if (NO_VALUE_OPERATORS.has(op)) return { field, op } as Predicate;

  const value = filterValueForOperator(op, filter['value']);
  if (value === '') throw httpError(400, 'Filter value is required.');
  return { field, op, value } as Predicate;
}

function filtersFromBody(body: Record<string, unknown>): Record<string, unknown>[] {
  const filters = Array.isArray(body['filters']) ? body['filters'].map(recordBody).filter((filter) => Object.keys(filter).length > 0) : [];
  if (filters.length > 0) return filters;
  return [recordBody(body['filter'])];
}

function predicateFromFilters(filters: Record<string, unknown>[], join: string): Predicate {
  const predicates = filters.map(predicateFromFilter);
  if (predicates.length === 1) return predicates[0];
  return join === 'any' ? ({ any: predicates } as Predicate) : ({ all: predicates } as Predicate);
}

function filterLogicTextForFilters(filters: Record<string, unknown>[], join: string): string {
  const joiner = join === 'any' ? ' OR ' : ' AND ';
  return filters.map(filterLogicText).join(joiner);
}

function actionsFromBody(body: Record<string, unknown>): RuleAction[] {
  const actions: RuleAction[] = [];
  const action = stringBody(body['action']).trim();
  const ifInStockAction = stringBody(body['ifInStockAction']).trim();
  const buysmartAction = stringBody(body['buysmartAction']).trim();
  const validation = stringBody(body['validation']).trim();
  const note = stringBody(body['note']).trim();

  if (Boolean(body['exclude'])) actions.push({ type: 'exclude', reason: stringBody(body['excludeReason']).trim() || 'User-managed exclusion rule' });
  if (action) actions.push({ type: 'set_action', value: action });
  if (ifInStockAction) actions.push({ type: 'set_if_stock', value: ifInStockAction });
  if (buysmartAction) actions.push({ type: 'set_buysmart', value: buysmartAction });
  if (Boolean(body['review'])) actions.push({ type: 'set_review', value: true });
  if (validation) actions.push({ type: 'append_validation', value: validation });
  if (note) actions.push({ type: 'add_note', value: note });
  if (actions.length === 0) throw httpError(400, 'Add at least one rule action.');
  return actions;
}

function actionsFromRequest(body: Record<string, unknown>, itemsValue: unknown): RuleAction[] {
  const itemActions = actionsFromItems(itemsValue);
  return itemActions.length ? itemActions : actionsFromBody(body);
}

function actionsFromItems(value: unknown): RuleAction[] {
  if (!Array.isArray(value)) return [];
  const actions = value.flatMap((item) => actionFromItem(recordBody(item)));
  if (actions.length === 0) throw httpError(400, 'Add at least one rule action.');
  return actions;
}

function actionFromItem(item: Record<string, unknown>): RuleAction[] {
  const type = stringBody(item['type']).trim();
  const value = stringBody(item['value']).trim();
  if (type === 'exclude') return [{ type: 'exclude', reason: stringBody(item['reason']).trim() || 'User-managed exclusion rule' }];
  if (type === 'set_review') return [{ type: 'set_review', value: true }];
  if (type === 'set_action') return value ? [{ type: 'set_action', value }] : [];
  if (type === 'set_if_stock') return value ? [{ type: 'set_if_stock', value }] : [];
  if (type === 'set_buysmart') return value ? [{ type: 'set_buysmart', value }] : [];
  if (type === 'append_validation') return value ? [{ type: 'append_validation', value }] : [];
  if (type === 'add_note') return value ? [{ type: 'add_note', value }] : [];
  throw httpError(400, 'Choose a supported action type.');
}

function sourceActionFields(actions: RuleAction[]): { action: string; ifInStockAction: string; buysmartAction: string; note: string } {
  return {
    action: firstActionValue(actions, 'set_action'),
    ifInStockAction: firstActionValue(actions, 'set_if_stock'),
    buysmartAction: firstActionValue(actions, 'set_buysmart'),
    note: actions.filter((action) => action.type === 'add_note').map((action) => stringBody(action.value)).filter(Boolean).join('; ')
  };
}

function firstActionValue(actions: RuleAction[], type: RuleAction['type']): string {
  return stringBody(actions.find((action) => action.type === type)?.value).trim();
}

function filterValueForOperator(op: string, value: unknown): JsonValue {
  if (NUMERIC_OPERATORS.has(op)) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) throw httpError(400, 'Filter value must be a number.');
    return parsed;
  }
  if (op === 'in' || op === 'not_in') {
    return stringBody(value)
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean);
  }
  return stringBody(value).trim();
}

function filterLogicText(filter: Record<string, unknown>): string {
  const field = ALLOWED_FILTER_FIELDS.get(stringBody(filter['field'])) ?? stringBody(filter['field']);
  const op = OPERATOR_LABELS.get(stringBody(filter['op'])) ?? stringBody(filter['op']);
  if (NO_VALUE_OPERATORS.has(stringBody(filter['op']))) return `${field} ${op}`;
  return `${field} ${op} ${stringBody(filter['value']).trim()}`;
}

function aggregateLogicText(actions: RuleAction[]): string {
  return actions
    .map((action) => {
      if (action.type === 'exclude') return `Exclude: ${action.reason ?? 'matched row'}`;
      if (action.type === 'set_review') return 'Flag for review';
      if (action.type === 'append_validation') return `Validation: ${stringBody(action.value)}`;
      if (action.type === 'add_note') return `Note: ${stringBody(action.value)}`;
      if (action.type === 'set_action') return `Set ACTION: ${stringBody(action.value)}`;
      if (action.type === 'set_if_stock') return `Set If In Stock: ${stringBody(action.value)}`;
      if (action.type === 'set_buysmart') return `Set BuySmart: ${stringBody(action.value)}`;
      return action.type;
    })
    .join(' | ');
}

function requestTypesFromBody(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(stringBody).map((item) => item.trim()).filter(Boolean);
  return stringBody(value)
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

function priorityFromBody(value: unknown, existingRules: RuleDefinition[], fallback?: number): number {
  if (value === undefined || value === null || value === '') return fallback ?? nextExecutionPriority(existingRules);
  const priority = Number(value);
  if (!Number.isInteger(priority) || priority < 1) throw httpError(400, 'Rule priority must be a positive whole number.');
  return priority;
}

function nextExecutionPriority(rules: RuleDefinition[]): number {
  return Math.max(
    900000,
    ...rules.flatMap((rule) => rule.variants.map((variant) => variant.executionPriority + 10))
  );
}

function cleanRuleId(value: string): string {
  return value.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
}

function nextUserRuleId(rules: RuleDefinition[]): string {
  const max = rules.reduce((highest, rule) => {
    const match = /^U(\d+)$/i.exec(rule.ruleId);
    return match ? Math.max(highest, Number(match[1])) : highest;
  }, 0);
  return `U${String(max + 1).padStart(3, '0')}`;
}

function recordBody(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}

function createRuleRun(
  batchId: string,
  mode: string,
  inputRowCount: number,
  changedRowCount: number,
  reviewRowCount: number,
  snapshot: RuleRun['ruleVersionSnapshot']
): RuleRun {
  const now = new Date().toISOString();
  return {
    id: newId(),
    batchId,
    status: 'completed',
    runMode: mode === 'selected_rows' ? 'selected_rows' : 'full_batch',
    ruleVersionSnapshot: snapshot,
    inputRowCount,
    changedRowCount,
    reviewRowCount,
    errorMessage: '',
    startedAt: now,
    completedAt: now
  };
}

function createResults(runId: string, beforeRows: WorkflowRow[], afterRows: WorkflowRow[], rowIds?: string[]): RowExecutionResult[] {
  const selected = rowIds?.length ? new Set(rowIds) : null;
  const beforeById = new Map(beforeRows.map((row) => [row.id, row]));
  return afterRows
    .filter((row) => !selected || selected.has(row.id))
    .filter((row) => JSON.stringify(decision(row)) !== JSON.stringify(decision(beforeById.get(row.id))) || row.executionTrace.length > 0)
    .map((row) => {
      const before = beforeById.get(row.id) ?? row;
      return {
        id: newId(),
        runId,
        workflowRowId: row.id,
        beforeState: before,
        afterState: row,
        trace: row.executionTrace,
        rulesApplied: row.executionTrace.map((trace) => trace.runtimeRuleId),
        validations: row.validationStatus ? row.validationStatus.split(';').map((item) => item.trim()) : [],
        createdAt: new Date().toISOString()
      };
    });
}

function decision(row?: WorkflowRow): Record<string, unknown> {
  if (!row) return {};
  return {
    action: row.action,
    ifInStockAction: row.ifInStockAction,
    buysmartAction: row.buysmartAction,
    needsReview: row.needsReview,
    excluded: row.excluded,
    outcome: row.outcomeReporting
  };
}

type RulePriorityLookup = Map<string, number>;
type ManualExportValue = string | number | boolean | Date | null;
type ManualExportColumn = {
  header: string;
  width: number;
  fill: string;
  numFmt?: string;
  value: (row: WorkflowRow) => ManualExportValue;
};

const MANUAL_HEADER_BLUE = 'BDD7EE';
const MANUAL_HEADER_PEACH = 'FCE4D6';
const MANUAL_HEADER_YELLOW = 'FFF2CC';
const MANUAL_HEADER_GREEN = 'E2F0D9';
const MANUAL_HEADER_WHITE = 'F2F2F2';

const manualExportColumns: ManualExportColumn[] = [
  { header: 'Business', width: 16, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.business, 'Business', 'business') },
  { header: 'Type', width: 12, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.requestType, 'Type', 'requestType') },
  { header: 'Case#', width: 18, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.caseNumber, 'Case#', 'Case #', 'caseNumber') },
  { header: 'Date Created', width: 13, fill: MANUAL_HEADER_BLUE, numFmt: 'm/d/yyyy', value: (row) => manualDateValue(row) },
  { header: 'Sector', width: 18, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.sector, 'Sector', 'sector') },
  { header: 'Division', width: 18, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.division, 'Division', 'division') },
  { header: 'Unit Name', width: 20, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.unitName, 'Unit Name', 'unitName') },
  { header: 'Unit Number', width: 13, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.unitNumber, 'Unit Number', 'unitNumber') },
  {
    header: 'Distributor Account Number',
    width: 14,
    fill: MANUAL_HEADER_BLUE,
    value: (row) => manualSourceText(row, 'Distributor Account Number', 'Distributor Account #', 'Distributor Account No', 'Distributor Account No.', 'Distributor Account')
  },
  { header: 'Vendor', width: 18, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.vendor, 'Vendor', 'vendor') },
  { header: 'Parent', width: 13, fill: MANUAL_HEADER_PEACH, value: (row) => manualSourceText(row, 'Parent') },
  { header: 'DST', width: 12, fill: MANUAL_HEADER_PEACH, value: (row) => manualSourceText(row, 'DST') },
  { header: 'DSTDIN', width: 14, fill: MANUAL_HEADER_PEACH, value: (row) => manualSourceText(row, 'DSTDIN', 'DST DIN') },
  { header: 'Item Code', width: 13, fill: MANUAL_HEADER_PEACH, value: (row) => manualSourceText(row, 'Item Code', 'ItemCode') },
  { header: 'Parent Category', width: 16, fill: MANUAL_HEADER_PEACH, value: (row) => manualTextOrSource(row, row.parentCategory, 'Parent Category', 'parentCategory') },
  { header: 'Sub Category', width: 16, fill: MANUAL_HEADER_PEACH, value: (row) => manualTextOrSource(row, row.subCategory, 'Sub Category', 'SubCategory', 'subCategory') },
  { header: 'DIN', width: 13, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.din, 'DIN', 'din') },
  { header: 'MIN', width: 14, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.min, 'MIN', 'min') },
  { header: 'Manufacturer', width: 18, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.manufacturer, 'Manufacturer', 'manufacturer') },
  { header: 'Brand', width: 16, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.brand, 'Brand', 'brand') },
  { header: 'Description', width: 28, fill: MANUAL_HEADER_PEACH, value: (row) => manualTextOrSource(row, row.description, 'Description', 'description') },
  { header: 'Supply Chain Description', width: 24, fill: MANUAL_HEADER_PEACH, value: (row) => manualSourceText(row, 'Supply Chain Description', 'Supply Chain Desc', 'Supply Chain Descr', 'Supply Chain Comment') },
  { header: 'Pack', width: 13, fill: MANUAL_HEADER_BLUE, value: (row) => manualSourceText(row, 'Pack') },
  { header: 'Usage', width: 10, fill: MANUAL_HEADER_BLUE, value: (row) => manualNumberOrSource(row, row.usageQty, 'Usage', 'usageQty') },
  { header: 'One-Time or Permanent', width: 18, fill: MANUAL_HEADER_BLUE, value: (row) => manualTextOrSource(row, row.oneTimeOrPermanent, 'One-Time or Permanent', 'oneTimeOrPermanent') },
  { header: 'Reason for request', width: 24, fill: MANUAL_HEADER_PEACH, value: (row) => manualTextOrSource(row, row.reasonForRequest, 'Reason for request', 'Reason for Request', 'reasonForRequest') },
  { header: 'Buysmart Action', width: 15, fill: 'FFFF00', value: (row) => manualTextOrSource(row, row.buysmartAction, 'Buysmart Action', 'Buy smart Action', 'Buy Smart Action', 'buysmartAction') },
  { header: 'DPL', width: 10, fill: MANUAL_HEADER_WHITE, value: (row) => manualTextOrSource(row, row.dpl, 'DPL', 'dpl') },
  { header: 'Meets Criteria', width: 14, fill: MANUAL_HEADER_WHITE, numFmt: '0%', value: (row) => manualPercentOrSource(row, row.meetsCriteria, 'Meets Criteria', 'meetsCriteria') },
  { header: 'In CAT', width: 10, fill: MANUAL_HEADER_WHITE, value: (row) => manualTextOrSource(row, row.inCat, 'In CAT', 'inCat') },
  { header: 'On MOG', width: 12, fill: MANUAL_HEADER_WHITE, value: (row) => manualTextOrSource(row, row.onMog, 'On MOG', 'onMog') },
  { header: 'Pantry', width: 12, fill: MANUAL_HEADER_WHITE, value: (row) => manualTextOrSource(row, row.pantry, 'Pantry', 'pantry') },
  { header: 'K12 APL', width: 12, fill: MANUAL_HEADER_WHITE, value: (row) => manualTextOrSource(row, row.k12Apl, 'K12 APL', 'k12Apl') },
  { header: 'Compass APL', width: 14, fill: MANUAL_HEADER_WHITE, value: (row) => manualTextOrSource(row, row.compassApl, 'Compass APL', 'compassApl') },
  { header: 'ACTION', width: 18, fill: MANUAL_HEADER_YELLOW, value: (row) => manualTextOrSource(row, row.action, 'ACTION', 'action') },
  { header: 'If In Stock: Action', width: 18, fill: MANUAL_HEADER_YELLOW, value: (row) => manualTextOrSource(row, row.ifInStockAction, 'If In Stock: Action', 'If in stock', 'ifInStockAction') },
  { header: 'Conversion DIN', width: 14, fill: MANUAL_HEADER_GREEN, value: (row) => manualTextOrSource(row, row.conversionDin, 'Conversion DIN', 'conversionDin') },
  { header: 'Conversion Manufacturer', width: 18, fill: MANUAL_HEADER_GREEN, value: (row) => manualSourceText(row, 'Conversion Manufacturer', 'Conversion Manufacturer Name') },
  { header: 'Conversion Mfr ID', width: 16, fill: MANUAL_HEADER_GREEN, value: (row) => manualSourceText(row, 'Conversion Mfr ID', 'Conversion Manufacturer ID', 'Conversion Mfr Id') },
  { header: 'Conversion Min', width: 14, fill: MANUAL_HEADER_GREEN, value: (row) => manualSourceText(row, 'Conversion Min', 'Conversion MIN') },
  { header: 'Conversion Ceres Catalog ID', width: 18, fill: MANUAL_HEADER_GREEN, value: (row) => manualSourceText(row, 'Conversion Ceres Catalog ID', 'Conversion Ceres Catalog', 'Conversion Ceres ID') },
  { header: 'Conversion Brand', width: 16, fill: MANUAL_HEADER_GREEN, value: (row) => manualSourceText(row, 'Conversion Brand') },
  { header: 'Conversion Item Description', width: 24, fill: MANUAL_HEADER_GREEN, value: (row) => manualSourceText(row, 'Conversion Item Description', 'Conversion Item Desc') },
  { header: 'Conversion Dist Item Pack Size', width: 18, fill: MANUAL_HEADER_GREEN, value: (row) => manualSourceText(row, 'Conversion Dist Item Pack Size', 'Conversion Distributor Item Pack Size', 'Conversion Pack Size') },
  { header: 'Audit Action', width: 16, fill: MANUAL_HEADER_YELLOW, value: (row) => manualSourceText(row, 'Audit Action') },
  { header: 'Conversion VA%', width: 14, fill: MANUAL_HEADER_GREEN, numFmt: '0%', value: (row) => manualPercentOrSource(row, row.conversionVaPct, 'Conversion VA%', 'conversionVaPct') }
];

async function exportManualXlsx(rows: WorkflowRow[]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Rules Execution Engine';
  workbook.created = new Date();
  workbook.modified = new Date();

  const worksheet = workbook.addWorksheet('Sheet1', {
    properties: { defaultRowHeight: 15 }
  });

  worksheet.columns = manualExportColumns.map((column) => ({
    header: column.header,
    key: column.header,
    width: column.width
  }));
  rows.forEach((row) => worksheet.addRow(manualExportColumns.map((column) => column.value(row))));

  worksheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: 1, column: manualExportColumns.length }
  };
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];

  const headerRow = worksheet.getRow(1);
  headerRow.height = 42;
  headerRow.eachCell((cell, columnNumber) => {
    const column = manualExportColumns[columnNumber - 1];
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: `FF${column.fill}` } };
    cell.font = { bold: true, color: { argb: 'FF000000' }, size: 10 };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = thinGridBorder();
  });

  manualExportColumns.forEach((column, index) => {
    const worksheetColumn = worksheet.getColumn(index + 1);
    if (column.numFmt) worksheetColumn.numFmt = column.numFmt;
    worksheetColumn.alignment = { horizontal: numericManualHeader(column.header) ? 'right' : 'left', vertical: 'middle' };
    worksheetColumn.eachCell({ includeEmpty: false }, (cell, rowNumber) => {
      if (rowNumber === 1) return;
      cell.border = thinGridBorder();
      cell.font = { size: 10 };
      cell.alignment = {
        horizontal: numericManualHeader(column.header) ? 'right' : 'left',
        vertical: 'middle',
        wrapText: false
      };
    });
  });

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

async function exportXlsx(rows: WorkflowRow[], priorityLookup: RulePriorityLookup): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Rules Execution Engine';
  const worksheet = workbook.addWorksheet('Outcomes');
  const headers = exportHeaders();
  worksheet.addRow(headers);
  rows.forEach((row) => worksheet.addRow(headers.map((header) => exportValue(row, header, priorityLookup))));
  worksheet.getRow(1).font = { bold: true };
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];
  sizeColumns(worksheet, headers);

  const ruleHeaders = appliedRuleHeaders();
  const ruleWorksheet = workbook.addWorksheet('Applied Rules');
  ruleWorksheet.addRow(ruleHeaders);
  rows.forEach((row) => {
    row.executionTrace.forEach((trace, index) => {
      ruleWorksheet.addRow(ruleHeaders.map((header) => appliedRuleValue(row, trace, index, header, priorityLookup)));
    });
  });
  ruleWorksheet.getRow(1).font = { bold: true };
  ruleWorksheet.views = [{ state: 'frozen', ySplit: 1 }];
  sizeColumns(ruleWorksheet, ruleHeaders);

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

function exportCsv(rows: WorkflowRow[], priorityLookup: RulePriorityLookup): string {
  const headers = exportHeaders();
  const lines = [headers.join(',')];
  for (const row of rows) {
    lines.push(headers.map((header) => csvCell(exportValue(row, header, priorityLookup))).join(','));
  }
  return lines.join('\n');
}

function exportHeaders(): string[] {
  return [
    'Business',
    'Type',
    'Case#',
    'Vendor',
    'DIN',
    'MIN',
    'Description',
    'ACTION',
    'If In Stock: Action',
    'Buysmart Action',
    'Assigned Bucket',
    'Rule Applied',
    'Applied Rule Count',
    'Applied Rule Priorities',
    'Applied Rule Actions',
    'Applied Rule Details',
    'Needs Review',
    'Validation Status',
    'Excluded',
    'Excluded Reason',
    'Compliance Bucket',
    'Outcome Reporting',
    'Analyst Notes'
  ];
}

function exportValue(row: WorkflowRow, header: string, priorityLookup: RulePriorityLookup): string | number | boolean | null {
  const values: Record<string, string | number | boolean | null> = {
    Business: row.business,
    Type: row.requestType,
    'Case#': row.caseNumber,
    Vendor: row.vendor,
    DIN: row.din,
    MIN: row.min,
    Description: row.description,
    ACTION: row.action,
    'If In Stock: Action': row.ifInStockAction,
    'Buysmart Action': row.buysmartAction,
    'Assigned Bucket': bucketForRow(row).label,
    'Rule Applied': row.ruleApplied,
    'Applied Rule Count': row.executionTrace.length,
    'Applied Rule Priorities': row.executionTrace.map((trace) => tracePriority(trace, priorityLookup)).filter((value) => value !== '').join('; '),
    'Applied Rule Actions': row.executionTrace.map((trace) => `${trace.runtimeRuleId || trace.ruleId}: ${trace.actionSummary || 'Matched'}`).join('\n'),
    'Applied Rule Details': row.executionTrace.map((trace) => ruleTraceDetail(trace, priorityLookup)).join('\n'),
    'Needs Review': row.needsReview,
    'Validation Status': row.validationStatus,
    Excluded: row.excluded,
    'Excluded Reason': row.excludedReason,
    'Compliance Bucket': bucketForRow(row).label,
    'Outcome Reporting': row.outcomeReporting,
    'Analyst Notes': row.analystNotes
  };
  return values[header] ?? '';
}

const MANUAL_NUMERIC_HEADERS = new Set(['Usage', 'Meets Criteria', 'Conversion VA%']);

function manualTextOrSource(row: WorkflowRow, directValue: unknown, ...sourceNames: string[]): string {
  const direct = manualCellText(directValue);
  return direct || manualSourceText(row, ...sourceNames);
}

function manualNumberOrSource(row: WorkflowRow, directValue: unknown, ...sourceNames: string[]): number | string | null {
  const direct = manualParseNumber(directValue);
  if (direct !== null) return direct;
  const source = manualSourceValue(row, sourceNames);
  const parsed = manualParseNumber(source);
  if (parsed !== null) return parsed;
  const text = manualCellText(source);
  return text || null;
}

function manualPercentOrSource(row: WorkflowRow, directValue: unknown, ...sourceNames: string[]): number | string | null {
  const direct = manualParsePercent(directValue);
  if (direct !== null) return direct;
  const source = manualSourceValue(row, sourceNames);
  const parsed = manualParsePercent(source);
  if (parsed !== null) return parsed;
  const text = manualCellText(source);
  return text || null;
}

function manualDateValue(row: WorkflowRow): Date | string | null {
  const source = manualSourceValue(row, ['Date Created', 'dateCreated']);
  const value = manualIsBlank(source) ? row.dateCreated : source;
  if (value instanceof Date && Number.isFinite(value.valueOf())) {
    return new Date(value.getFullYear(), value.getMonth(), value.getDate());
  }
  if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
    const excelEpochOffset = 25569;
    const date = new Date(Math.round((value - excelEpochOffset) * 86400 * 1000));
    return new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
  }
  const text = manualCellText(value);
  if (!text) return null;
  const isoDate = /^(\d{4})-(\d{2})-(\d{2})/.exec(text);
  if (isoDate) return new Date(Number(isoDate[1]), Number(isoDate[2]) - 1, Number(isoDate[3]));
  const parsed = new Date(text);
  if (!Number.isNaN(parsed.valueOf())) {
    return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
  }
  return text;
}

function manualSourceText(row: WorkflowRow, ...sourceNames: string[]): string {
  return manualCellText(manualSourceValue(row, sourceNames));
}

function manualSourceValue(row: WorkflowRow, sourceNames: string[]): unknown {
  const bags: Array<Record<string, unknown> | undefined> = [
    row.rawRow as Record<string, unknown>,
    row.normalizedRow?.source as Record<string, unknown> | undefined,
    row.normalizedRow?.fields as Record<string, unknown> | undefined
  ];
  const normalizedNames = new Set(sourceNames.map((name) => manualFieldKey(name)));
  for (const bag of bags) {
    if (!bag) continue;
    for (const name of sourceNames) {
      const value = bag[name];
      if (!manualIsBlank(value)) return value;
    }
    for (const [key, value] of Object.entries(bag)) {
      if (normalizedNames.has(manualFieldKey(key)) && !manualIsBlank(value)) return value;
    }
  }
  return '';
}

function manualCellText(value: unknown): string {
  if (manualIsBlank(value)) return '';
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map((item) => manualCellText(item)).filter(Boolean).join('; ');
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value).replace(/\s+/g, ' ').trim();
}

function manualParseNumber(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const text = manualCellText(value);
  if (!text || /^blank$/i.test(text)) return null;
  const parsed = Number(text.replace(/,/g, '').replace(/%/g, '').trim());
  return Number.isFinite(parsed) ? parsed : null;
}

function manualParsePercent(value: unknown): number | null {
  const parsed = manualParseNumber(value);
  if (parsed === null) return null;
  return parsed > 1 ? parsed / 100 : parsed;
}

function manualFieldKey(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function manualIsBlank(value: unknown): boolean {
  return value === null || value === undefined || (typeof value === 'string' && value.trim() === '');
}

function numericManualHeader(header: string): boolean {
  return MANUAL_NUMERIC_HEADERS.has(header);
}

function thinGridBorder(): Partial<ExcelJS.Borders> {
  const line: Partial<ExcelJS.Border> = { style: 'thin', color: { argb: 'FFD9D9D9' } };
  return {
    top: line,
    left: line,
    bottom: line,
    right: line
  };
}

function appliedRuleHeaders(): string[] {
  return [
    'Source Row',
    'Case#',
    'Business',
    'Type',
    'Vendor',
    'DIN',
    'MIN',
    'Description',
    'Trace Order',
    'Rule Priority',
    'Rule ID',
    'Runtime Rule ID',
    'Runtime Kind',
    'Rule Description',
    'Associated Rule Action',
    'Matched At',
    'Final ACTION',
    'Final If In Stock: Action',
    'Final Buysmart Action',
    'Compliance Bucket',
    'Outcome Reporting',
    'Needs Review',
    'Excluded',
    'Excluded Reason'
  ];
}

function appliedRuleValue(
  row: WorkflowRow,
  trace: WorkflowRow['executionTrace'][number],
  index: number,
  header: string,
  priorityLookup: RulePriorityLookup
): string | number | boolean | null {
  const values: Record<string, string | number | boolean | null> = {
    'Source Row': row.sourceRowNumber,
    'Case#': row.caseNumber,
    Business: row.business,
    Type: row.requestType,
    Vendor: row.vendor,
    DIN: row.din,
    MIN: row.min,
    Description: row.description,
    'Trace Order': index + 1,
    'Rule Priority': tracePriority(trace, priorityLookup),
    'Rule ID': trace.ruleId,
    'Runtime Rule ID': trace.runtimeRuleId,
    'Runtime Kind': trace.runtimeKind,
    'Rule Description': trace.description,
    'Associated Rule Action': trace.actionSummary,
    'Matched At': trace.matchedAt,
    'Final ACTION': row.action,
    'Final If In Stock: Action': row.ifInStockAction,
    'Final Buysmart Action': row.buysmartAction,
    'Compliance Bucket': bucketForRow(row).label,
    'Outcome Reporting': row.outcomeReporting,
    'Needs Review': row.needsReview,
    Excluded: row.excluded,
    'Excluded Reason': row.excludedReason
  };
  return values[header] ?? '';
}

function ruleTraceDetail(trace: WorkflowRow['executionTrace'][number], priorityLookup: RulePriorityLookup): string {
  const resolvedPriority = tracePriority(trace, priorityLookup);
  const priority = resolvedPriority === '' ? 'No priority' : `Priority ${resolvedPriority}`;
  const runtime = trace.runtimeRuleId || trace.ruleId || 'Unknown rule';
  const kind = trace.runtimeKind ? ` ${trace.runtimeKind}` : '';
  const description = trace.description ? ` - ${trace.description}` : '';
  const action = trace.actionSummary ? ` => ${trace.actionSummary}` : '';
  return `${priority} ${runtime}${kind}${description}${action}`;
}

function tracePriority(trace: WorkflowRow['executionTrace'][number], priorityLookup: RulePriorityLookup): number | '' {
  const rawPriority = Number((trace as { executionPriority?: unknown }).executionPriority);
  if (Number.isFinite(rawPriority) && rawPriority > 0) return rawPriority;
  const runtimeRuleId = String((trace as { runtimeRuleId?: unknown }).runtimeRuleId ?? '');
  const ruleId = String((trace as { ruleId?: unknown }).ruleId ?? '');
  return priorityLookup.get(runtimeRuleId) ?? priorityLookup.get(ruleId) ?? '';
}

function rulePriorityLookup(rules: RuleDefinition[]): RulePriorityLookup {
  const lookup: RulePriorityLookup = new Map();
  rules.forEach((rule) => {
    const priorities = rule.variants.map((variant) => variant.executionPriority).filter((priority) => Number.isFinite(priority));
    const firstPriority = priorities.length ? Math.min(...priorities) : undefined;
    if (firstPriority !== undefined) lookup.set(rule.ruleId, firstPriority);
    rule.variants.forEach((variant) => {
      lookup.set(variant.runtimeRuleId, variant.executionPriority);
    });
  });
  return lookup;
}

function sizeColumns(worksheet: ExcelJS.Worksheet, headers: string[]): void {
  worksheet.columns.forEach((column, index) => {
    column.width = Math.min(Math.max((headers[index] ?? '').length + 4, 14), 44);
  });
}

function csvCell(value: string | number | boolean | null): string {
  const text = String(value ?? '');
  if (/[",\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
}

function getPath(req: VercelRequest): string[] {
  const raw = req.query['path'];
  if (Array.isArray(raw)) return raw.map(String);
  if (typeof raw === 'string') return raw.split('/').filter(Boolean);
  return [];
}

function pathEquals(path: string[], ...parts: string[]): boolean {
  return path.length === parts.length && parts.every((part, index) => path[index] === part);
}

function getUrl(req: VercelRequest): URL {
  const host = req.headers.host ?? 'localhost';
  return new URL(req.url ?? '/', `http://${host}`);
}

async function readJson(req: VercelRequest, optional = false): Promise<Record<string, unknown>> {
  if (req.body && typeof req.body === 'object') return req.body as Record<string, unknown>;
  if (typeof req.body === 'string' && req.body.trim()) return JSON.parse(req.body) as Record<string, unknown>;
  const chunks: Buffer[] = [];
  for await (const chunk of req) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  const raw = Buffer.concat(chunks).toString('utf8').trim();
  if (!raw && optional) return {};
  if (!raw) throw httpError(400, 'JSON body is required.');
  return JSON.parse(raw) as Record<string, unknown>;
}

function base64ToBuffer(value: string): Buffer {
  const clean = value.includes(',') ? value.split(',').pop() ?? '' : value;
  return Buffer.from(clean, 'base64');
}

function stringBody(value: unknown): string {
  return value === null || value === undefined ? '' : String(value);
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function sendJson(res: VercelResponse, status: number, payload: unknown): void {
  res.status(status).json(payload);
}

function sendFile(res: VercelResponse, status: number, body: Buffer, contentType: string, fileName: string): void {
  res.setHeader('content-type', contentType);
  res.setHeader('content-disposition', `attachment; filename="${fileName}"`);
  res.status(status).send(body);
}

function setCommonHeaders(res: VercelResponse): void {
  res.setHeader('access-control-allow-methods', 'GET,POST,PATCH,DELETE,OPTIONS');
  res.setHeader('access-control-allow-headers', 'content-type');
  res.setHeader('x-rules-engine', 'compliance-rules');
}

function httpError(statusCode: number, message: string): Error & { statusCode: number } {
  const error = new Error(message) as Error & { statusCode: number };
  error.statusCode = statusCode;
  return error;
}
