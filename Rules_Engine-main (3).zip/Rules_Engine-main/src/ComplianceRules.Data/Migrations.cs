public static class Migrations
{
    public static readonly string[] Statements =
    [
        "create extension if not exists pgcrypto",
        """
        create table if not exists source_batches (
          id uuid primary key,
          name text not null,
          source_kind text not null check (source_kind in ('upload','warehouse','sample')),
          reporting_date text not null,
          status text not null default 'draft',
          row_count integer not null default 0,
          source_file_name text not null,
          source_sheet_name text not null,
          file_sha256 text not null,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now()
        )
        """,
        """
        create table if not exists workflow_rows (
          id uuid primary key,
          batch_id uuid not null references source_batches(id) on delete cascade,
          source_row_number integer not null,
          workflow_request_key text not null,
          raw_row jsonb not null,
          normalized_row jsonb not null,
          business text,
          request_type text,
          case_number text,
          date_created text,
          sector text,
          division text,
          unit_name text,
          unit_number text,
          vendor text,
          din text,
          min text,
          manufacturer text,
          brand text,
          description text,
          parent_category text,
          sub_category text,
          usage_qty numeric,
          one_time_or_permanent text,
          reason_for_request text,
          dpl text,
          meets_criteria numeric,
          in_cat text,
          on_mog text,
          pantry text,
          k12_apl text,
          compass_apl text,
          conversion_din text,
          conversion_va_pct numeric,
          upstream_action text,
          upstream_if_in_stock_action text,
          action text,
          if_in_stock_action text,
          buysmart_action text,
          rule_applied text,
          execution_trace jsonb not null default '[]'::jsonb,
          needs_review boolean not null default false,
          analyst_notes text,
          validation_status text,
          excluded boolean not null default false,
          excluded_reason text,
          queue_bucket text,
          request_bucket text,
          outcome_reporting text,
          selected boolean not null default false,
          assignment text,
          status text not null default 'Ready',
          last_sync_at text,
          last_saved_at text,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now(),
          unique (batch_id, source_row_number)
        )
        """,
        """
        create table if not exists rule_definitions (
          id uuid primary key,
          rule_id text not null unique,
          name text not null,
          rule_group text,
          business_scope text,
          request_types jsonb not null default '[]'::jsonb,
          discovery_reference text,
          notes text,
          owner_team text,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now()
        )
        """,
        """
        create table if not exists rule_versions (
          id uuid primary key,
          rule_definition_id uuid not null references rule_definitions(id) on delete cascade,
          version_number integer not null,
          status text not null check (status in ('draft','ready','approved','disabled','archived')),
          automation_level text not null check (automation_level in ('alpha','guided','manual','future')),
          change_reason text,
          created_at timestamptz not null default now(),
          unique (rule_definition_id, version_number)
        )
        """,
        """
        create table if not exists rule_variants (
          id uuid primary key,
          rule_version_id uuid not null references rule_versions(id) on delete cascade,
          runtime_rule_id text not null,
          runtime_kind text not null check (runtime_kind in ('row_rule','validation_rule','buysmart_rule','downstream_rule')),
          execution_priority integer not null,
          enabled boolean not null default true,
          is_executable boolean not null default false,
          stop_processing boolean not null default false,
          predicate_json jsonb,
          action_json jsonb,
          description text,
          automation_level text not null,
          status text not null,
          source jsonb not null,
          created_at timestamptz not null default now(),
          unique (rule_version_id, runtime_rule_id)
        )
        """,
        """
        create table if not exists rule_runs (
          id uuid primary key,
          batch_id uuid not null references source_batches(id) on delete cascade,
          status text not null check (status in ('queued','running','completed','failed','cancelled')),
          run_mode text not null check (run_mode in ('full_batch','selected_rows','simulation')),
          rule_version_snapshot jsonb not null,
          input_row_count integer not null default 0,
          changed_row_count integer not null default 0,
          review_row_count integer not null default 0,
          error_message text,
          started_at timestamptz not null default now(),
          completed_at timestamptz
        )
        """,
        """
        create table if not exists row_execution_results (
          id uuid primary key,
          run_id uuid not null references rule_runs(id) on delete cascade,
          workflow_row_id uuid not null references workflow_rows(id) on delete cascade,
          before_state jsonb not null,
          after_state jsonb not null,
          trace jsonb not null,
          rules_applied jsonb not null default '[]'::jsonb,
          validations jsonb not null default '[]'::jsonb,
          created_at timestamptz not null default now(),
          unique (run_id, workflow_row_id)
        )
        """,
        """
        create table if not exists analyst_overrides (
          id uuid primary key,
          workflow_row_id uuid not null references workflow_rows(id) on delete cascade,
          field_name text not null,
          old_value text,
          new_value text,
          reason text,
          created_at timestamptz not null default now()
        )
        """,
        """
        create table if not exists audit_events (
          id uuid primary key,
          actor_id uuid,
          event_type text not null,
          entity_type text not null,
          entity_id uuid,
          payload jsonb not null default '{}'::jsonb,
          created_at timestamptz not null default now()
        )
        """,
        "create index if not exists workflow_rows_batch_idx on workflow_rows(batch_id)",
        "create index if not exists workflow_rows_business_idx on workflow_rows(batch_id, business)",
        "create index if not exists workflow_rows_type_idx on workflow_rows(batch_id, request_type)",
        "create index if not exists workflow_rows_status_idx on workflow_rows(batch_id, status)",
        "create index if not exists workflow_rows_review_idx on workflow_rows(batch_id, needs_review)",
        "create index if not exists workflow_rows_outcome_idx on workflow_rows(batch_id, outcome_reporting)"
    ];
}

