import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../services/api.service';
import { BatchSelectionService } from '../services/batch-selection.service';
import type { RuleDefinition, RuleRun, SourceBatch } from '../models';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="page-title">
      <div>
        <p>Execution Console</p>
        <h1>Run saved rules</h1>
      </div>
      <button class="button ghost" (click)="refresh()">Refresh</button>
    </section>

    <section class="panel console">
      <div class="toolbar">
        <label class="field grow">
          <span>Batch</span>
          <select [(ngModel)]="selectedBatchId" (change)="onBatchChange()" [disabled]="loadingBatches || !batches.length">
            <option value="">{{ loadingBatches ? 'Loading batches' : batches.length ? 'Select batch' : 'No batches' }}</option>
            @for (batch of batches; track batch.id) {
              <option [value]="batch.id">{{ batch.name }} ({{ batch.rowCount }} rows)</option>
            }
          </select>
        </label>
        <button class="button secondary" (click)="run(true)" [disabled]="busy || !selectedBatchId">Dry Run</button>
        <button class="button" (click)="run(false)" [disabled]="busy || !selectedBatchId">Execute</button>
      </div>

      <div class="rule-strip">
        <span class="tag info">{{ rules.length }} saved rules</span>
        <span class="tag good">{{ executableCount }} ready rules</span>
        <span class="tag warn">{{ guidedCount }} guided/reference rules</span>
      </div>
    </section>

    @if (runResult) {
      <section class="kpi-grid run-grid">
        <article class="panel kpi"><small>Input Rows</small><strong>{{ runResult.inputRowCount }}</strong></article>
        <article class="panel kpi"><small>Changed Rows</small><strong>{{ runResult.changedRowCount }}</strong></article>
        <article class="panel kpi"><small>Review Rows</small><strong>{{ runResult.reviewRowCount }}</strong></article>
        <article class="panel kpi"><small>Status</small><strong>{{ runResult.status }}</strong></article>
      </section>
    }

    @if (message) {
      <div class="empty">{{ message }}</div>
    }
  `,
  styles: [
    `
      .page-title {
        display: flex;
        justify-content: space-between;
        align-items: end;
        margin-bottom: var(--space-16);
      }

      .page-title p {
        margin: 0 0 var(--space-4);
        color: var(--primary-600);
        font-weight: 700;
        text-transform: uppercase;
      }

      .page-title h1 {
        margin: 0;
      }

      .console {
        padding: var(--space-16);
      }

      .grow {
        flex: 1 1 320px;
      }

      .rule-strip {
        display: flex;
        flex-wrap: wrap;
        gap: var(--space-8);
        margin-top: var(--space-16);
      }

      .run-grid {
        margin-top: var(--space-16);
      }
    `
  ]
})
export class ExecutionConsoleComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly batchSelection = inject(BatchSelectionService);
  batches: SourceBatch[] = [];
  rules: RuleDefinition[] = [];
  selectedBatchId = '';
  loadingBatches = true;
  busy = false;
  message = '';
  runResult: RuleRun | null = null;

  get executableCount(): number {
    return this.rules.flatMap((rule) => rule.variants).filter((variant) => variant.isExecutable).length;
  }

  get guidedCount(): number {
    return this.rules.flatMap((rule) => rule.variants).filter((variant) => !variant.isExecutable).length;
  }

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    this.loadingBatches = true;
    try {
      const [batches, rules] = await Promise.all([this.api.listBatches(), this.api.listRules()]);
      this.batches = batches;
      this.rules = rules;
      this.selectedBatchId = this.batchSelection.chooseBatch(this.batches, this.selectedBatchId);
    } finally {
      this.loadingBatches = false;
    }
  }

  onBatchChange(): void {
    this.batchSelection.save(this.selectedBatchId);
  }

  async run(dryRun: boolean): Promise<void> {
    if (!this.selectedBatchId) return;
    this.busy = true;
    this.message = '';
    try {
      const result = await this.api.runBatch(this.selectedBatchId, dryRun);
      this.runResult = result.run;
      this.batchSelection.save(this.selectedBatchId);
      this.message = result.dryRun ? 'Dry run complete. No rows were saved.' : 'Execution complete and workflow rows were saved.';
    } finally {
      this.busy = false;
    }
  }
}
