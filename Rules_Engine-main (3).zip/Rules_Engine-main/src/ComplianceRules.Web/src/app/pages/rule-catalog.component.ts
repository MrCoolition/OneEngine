import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../services/api.service';
import { READY_HEALTH } from '../services/readiness-defaults';
import type { RuleActionItemRequest, RuleCreateRequest, RuleDefinition, RuleFilterRequest } from '../models';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="page-title">
      <div>
        <p>Rules</p>
        <h1>Compliance rule catalog</h1>
        <p class="page-copy">Saved DAF logic drives the PRF/SORF/SRF workflow.</p>
      </div>
      <div class="toolbar">
        <button class="button" (click)="openCreate()">{{ showCreate ? 'Close Builder' : 'New Rule' }}</button>
        <button class="button secondary" (click)="refreshRules()" [disabled]="busy">{{ busy ? 'Refreshing' : 'Refresh Rules' }}</button>
      </div>
    </section>

    @if (showCreate) {
      <section class="panel rule-builder">
        <div class="builder-head">
          <div>
            <h2>{{ isEditing ? 'Edit rule' : 'Create rule' }}</h2>
            <p>{{ isEditing ? 'Change the saved filter, actions, and run state for this rule.' : 'Build a saved compliance rule from a source-row filter and the actions to apply when it matches.' }}</p>
          </div>
          <span class="tag good">{{ draft.enabled ? 'Enabled' : 'Disabled' }}</span>
        </div>

        <div class="builder-grid">
          <label class="field">
            <span>Rule ID</span>
            <input [(ngModel)]="draft.ruleId" placeholder="Auto" [disabled]="isEditing">
          </label>
          <label class="field span-2">
            <span>Name</span>
            <input [(ngModel)]="draft.name" placeholder="Route vendor exception">
          </label>
          <label class="field">
            <span>Group</span>
            <input [(ngModel)]="draft.ruleGroup" placeholder="User Managed">
          </label>
          <label class="field">
            <span>Business scope</span>
            <input [(ngModel)]="draft.businessScope" placeholder="All">
          </label>
          <label class="field">
            <span>Request types</span>
            <input [(ngModel)]="draft.requestTypes" placeholder="PRF, SORF, SRF">
          </label>
          <label class="field">
            <span>Rule Priority</span>
            <input type="number" min="1" step="1" [(ngModel)]="draft.executionPriority" placeholder="900000">
          </label>
        </div>

        <div class="builder-section">
          <div class="section-head">
            <div>
              <h3>Filters</h3>
              <p>{{ draft.filterJoin === 'any' ? 'Match any filter row.' : 'Match all filter rows.' }}</p>
            </div>
            <div class="toolbar">
              <label class="field compact-field">
                <span>Match</span>
                <select [(ngModel)]="draft.filterJoin">
                  <option value="all">All filters</option>
                  <option value="any">Any filter</option>
                </select>
              </label>
              <button class="mini-button" (click)="addFilter()">Add Filter</button>
            </div>
          </div>

          <div class="dynamic-list">
            @for (filterRow of draft.filters; track filterRow; let index = $index) {
              <div class="dynamic-row filter-row">
                <label class="field">
                  <span>Filter field</span>
                  <select [(ngModel)]="filterRow.field">
                    @for (option of fieldOptions; track option.value) {
                      <option [value]="option.value">{{ option.label }}</option>
                    }
                  </select>
                </label>
                <label class="field">
                  <span>Operator</span>
                  <select [(ngModel)]="filterRow.op" (ngModelChange)="normalizeFilterValue(filterRow)">
                    @for (option of operatorOptions; track option.value) {
                      <option [value]="option.value">{{ option.label }}</option>
                    }
                  </select>
                </label>
                @if (operatorNeedsValue(filterRow.op)) {
                  <label class="field">
                    <span>Value</span>
                    <input [(ngModel)]="filterRow.value" placeholder="Compass USA, Baldor, 10">
                  </label>
                } @else {
                  <div class="field value-placeholder">
                    <span>Value</span>
                    <div>No value needed</div>
                  </div>
                }
                <button class="mini-button danger" (click)="removeFilter(index)" [disabled]="(draft.filters?.length || 0) === 1">Remove</button>
              </div>
            }
          </div>
        </div>

        <div class="builder-section">
          <div class="section-head">
            <div>
              <h3>Actions</h3>
              <p>Actions run in the order shown when the filters match.</p>
            </div>
            <button class="mini-button" (click)="addActionItem()">Add Action</button>
          </div>

          <div class="dynamic-list">
            @for (actionItem of draft.actionItems; track actionItem; let index = $index) {
              <div class="dynamic-row action-row">
                <label class="field">
                  <span>Action type</span>
                  <select [(ngModel)]="actionItem.type" (ngModelChange)="normalizeActionItem(actionItem)">
                    @for (option of actionItemOptions; track option.value) {
                      <option [value]="option.value">{{ option.label }}</option>
                    }
                  </select>
                </label>

                @if (actionItem.type === 'set_action') {
                  <label class="field">
                    <span>ACTION</span>
                    <select [(ngModel)]="actionItem.value">
                      @for (option of selectableActionOptions; track option.value) {
                        <option [value]="option.value">{{ option.label }}</option>
                      }
                    </select>
                  </label>
                } @else if (actionItem.type === 'set_if_stock') {
                  <label class="field">
                    <span>If in stock</span>
                    <select [(ngModel)]="actionItem.value">
                      @for (option of selectableIfStockOptions; track option.value) {
                        <option [value]="option.value">{{ option.label }}</option>
                      }
                    </select>
                  </label>
                } @else if (actionItem.type === 'set_buysmart') {
                  <label class="field">
                    <span>BuySmart</span>
                    <select [(ngModel)]="actionItem.value">
                      @for (option of selectableBuysmartOptions; track option.value) {
                        <option [value]="option.value">{{ option.label }}</option>
                      }
                    </select>
                  </label>
                } @else if (actionItem.type === 'append_validation') {
                  <label class="field">
                    <span>Validation</span>
                    <input [(ngModel)]="actionItem.value" placeholder="Missing identifier, policy exception">
                  </label>
                } @else if (actionItem.type === 'add_note') {
                  <label class="field">
                    <span>Note</span>
                    <input [(ngModel)]="actionItem.value" placeholder="Optional analyst note">
                  </label>
                } @else if (actionItem.type === 'exclude') {
                  <label class="field">
                    <span>Exclude reason</span>
                    <input [(ngModel)]="actionItem.reason" placeholder="Removed from managed workflow">
                  </label>
                } @else {
                  <div class="field value-placeholder">
                    <span>Value</span>
                    <div>Flag matched rows</div>
                  </div>
                }

                <button class="mini-button danger" (click)="removeActionItem(index)" [disabled]="(draft.actionItems?.length || 0) === 1">Remove</button>
              </div>
            }
          </div>
        </div>

        <div class="builder-switches">
          <label><input type="checkbox" [(ngModel)]="draft.stopProcessing"> Stop after match</label>
          <label><input type="checkbox" [(ngModel)]="draft.enabled"> Enabled</label>
        </div>

        <div class="builder-actions">
          <button class="button" (click)="saveRule()" [disabled]="saving">{{ saving ? 'Saving Rule' : isEditing ? 'Save Changes' : 'Create Rule' }}</button>
          <button class="button ghost" (click)="resetOrCancelDraft()" [disabled]="saving">{{ isEditing ? 'Cancel' : 'Reset' }}</button>
        </div>
      </section>
    }

    <section class="panel catalog-tools">
      <label class="field">
        <span>Filter</span>
        <input [(ngModel)]="filter" placeholder="R001, Canada, approval, manual">
      </label>
      @if (statusFilter === 'ready') {
        <div class="active-filters" aria-label="Active filters">
          <span class="tag good">Ready rules</span>
          <button class="filter-clear" type="button" (click)="clearStatusFilter()">Clear</button>
        </div>
      }
      <div class="rule-totals">
        <span class="tag info">{{ displayRuleCount }} saved</span>
        <span class="tag good">{{ displayExecutableCount }} ready</span>
        <span class="tag warn">{{ displayManualCount }} guided</span>
      </div>
    </section>

    @if (message) {
      <div class="alert info catalog-message">{{ message }}</div>
    }

    @if (loading) {
      <div class="panel empty">Refreshing rule catalog.</div>
    } @else if (error) {
      <div class="alert bad catalog-message">{{ error }}</div>
    } @else {
      <section class="panel rules-table">
        <div class="rule-row table-head">
          <span>Rule Priority</span>
          <span>Rule</span>
          <span>Scope</span>
          <span>Runs</span>
          <span>Status</span>
          <span>Logic</span>
          <span>Manage</span>
        </div>
        @for (rule of filteredRules; track rule.ruleId) {
          <div class="rule-row" [class.disabled-rule]="isRuleDisabled(rule)">
            <div class="priority-cell">
              <strong>{{ rulePriority(rule) }}</strong>
              <small>{{ runtimeKindLabel(rule) }}</small>
            </div>
            <div>
              <strong>{{ rule.ruleId }}</strong>
              <small>{{ rule.ruleGroup || 'Ungrouped' }}</small>
            </div>
            <div>
              <span>{{ rule.businessScope || 'All' }}</span>
              <small>{{ rule.requestTypes.join(', ') || 'All types' }}</small>
            </div>
            <div>
              <span>{{ executableFor(rule) }} ready</span>
              <small>{{ rule.variants.length }} total</small>
            </div>
            <div>
              <span [class]="statusClass(rule)">{{ automationLabel(rule) }}</span>
            </div>
            <div class="logic-cell">
              <b>Filter</b>
              <span>{{ fieldFilter(rule) }}</span>
              <b>Aggregate</b>
              <span>{{ aggregateLogic(rule) }}</span>
            </div>
            <div class="manage-actions">
              <button class="mini-button" (click)="editRule(rule)" [disabled]="busyRuleId === rule.ruleId">Edit</button>
              <button class="mini-button" (click)="toggleRule(rule)" [disabled]="busyRuleId === rule.ruleId">
                {{ busyRuleId === rule.ruleId ? 'Saving' : isRuleDisabled(rule) ? 'Enable' : 'Disable' }}
              </button>
            </div>
          </div>
        } @empty {
          <div class="empty">No rules matched that filter.</div>
        }
      </section>
    }
  `,
  styles: [
    `
      .catalog-tools {
        display: flex;
        flex-wrap: wrap;
        align-items: end;
        justify-content: space-between;
        gap: var(--space-16);
        padding: var(--space-16);
      }

      .catalog-tools .field {
        flex: 1 1 320px;
      }

      .rule-builder {
        display: grid;
        gap: var(--space-16);
        margin-bottom: var(--space-16);
        padding: var(--space-16);
      }

      .builder-head {
        display: flex;
        justify-content: space-between;
        gap: var(--space-16);
        align-items: start;
        padding-bottom: var(--space-12);
        border-bottom: 1px solid var(--line);
      }

      .builder-head h2,
      .builder-head p {
        margin: 0;
      }

      .builder-head h2 {
        font-size: 1rem;
        font-weight: 600;
      }

      .builder-head p {
        margin-top: var(--space-4);
        color: var(--muted);
      }

      .builder-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: var(--space-12);
      }

      .span-2 {
        grid-column: span 2;
      }

      .builder-section {
        display: grid;
        gap: var(--space-12);
        padding: var(--space-12);
        border: 1px solid var(--line);
        border-radius: var(--radius-md);
        background: var(--neutral-50);
      }

      .section-head {
        display: flex;
        justify-content: space-between;
        gap: var(--space-12);
        align-items: end;
      }

      .section-head h3,
      .section-head p {
        margin: 0;
      }

      .section-head h3 {
        font-size: 1rem;
        font-weight: 600;
      }

      .section-head p {
        margin-top: var(--space-4);
        color: var(--muted);
      }

      .compact-field {
        min-width: 150px;
      }

      .dynamic-list {
        display: grid;
        gap: var(--space-8);
      }

      .dynamic-row {
        display: grid;
        grid-template-columns: minmax(180px, 1fr) minmax(170px, 0.75fr) minmax(240px, 1.4fr) 96px;
        gap: var(--space-12);
        align-items: end;
        padding: var(--space-12);
        border: 1px solid var(--line);
        border-radius: var(--radius-sm);
        background: var(--surface);
      }

      .value-placeholder div {
        min-height: 2.7rem;
        display: flex;
        align-items: center;
        border: 1px dashed var(--line);
        border-radius: var(--radius-sm);
        padding: 0 var(--space-12);
        color: var(--muted);
        background: var(--neutral-50);
      }

      .builder-switches {
        display: flex;
        flex-wrap: wrap;
        gap: var(--space-12) var(--space-16);
        align-items: center;
        color: var(--ink);
        font-weight: 600;
      }

      .builder-switches label {
        display: inline-flex;
        gap: var(--space-8);
        align-items: center;
      }

      .builder-actions {
        display: flex;
        flex-wrap: wrap;
        gap: var(--space-8);
      }

      .rule-totals {
        display: flex;
        flex-wrap: wrap;
        gap: var(--space-8);
      }

      .active-filters {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: var(--space-8);
      }

      .filter-clear {
        min-height: 44px;
        padding: var(--space-8) var(--space-12);
        border: 1px solid var(--line);
        border-radius: var(--radius-sm);
        background: var(--surface);
        color: var(--primary-600);
        font-size: 0.75rem;
        font-weight: 700;
      }

      .filter-clear:hover:not(:disabled) {
        border-color: var(--primary-500);
        background: var(--primary-50);
      }

      .catalog-message {
        margin-top: var(--space-12);
      }

      .rules-table {
        margin-top: var(--space-12);
        overflow-x: auto;
      }

      .rule-row {
        display: grid;
        grid-template-columns: 82px 100px 0.9fr 110px 100px minmax(260px, 1.5fr) 140px;
        min-width: 1000px;
        gap: var(--space-12);
        align-items: start;
        padding: var(--space-12) var(--space-16);
        border-bottom: 1px solid var(--line);
        font-size: 0.875rem;
      }

      .rule-row:last-child {
        border-bottom: 0;
      }

      .rule-row:hover:not(.table-head) {
        background: var(--primary-50);
      }

      .disabled-rule {
        background: var(--neutral-50);
        color: var(--muted);
      }

      .table-head {
        background: var(--neutral-50);
        color: var(--neutral-700);
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
      }

      .rule-row strong,
      .rule-row span,
      .rule-row small {
        display: block;
      }

      .rule-row strong {
        font-size: 0.875rem;
        font-weight: 700;
      }

      .rule-row small {
        margin-top: var(--space-2);
        color: var(--muted);
      }

      .logic-cell {
        color: var(--neutral-700);
        line-height: 1.35;
      }

      .priority-cell strong {
        font-variant-numeric: tabular-nums;
      }

      .logic-cell b,
      .logic-cell span {
        display: block;
      }

      .logic-cell b {
        color: var(--ink);
        font-size: 0.75rem;
        margin-top: var(--space-2);
        text-transform: uppercase;
      }

      .logic-cell span {
        margin-bottom: var(--space-4);
      }

      .manage-actions {
        display: grid;
        gap: var(--space-8);
      }

      .mini-button {
        min-height: 44px;
        width: 100%;
        border: 1px solid var(--line);
        border-radius: var(--radius-sm);
        background: var(--surface);
        color: var(--primary-600);
        font-weight: 700;
        cursor: pointer;
      }

      .mini-button:hover:not(:disabled) {
        border-color: var(--primary-500);
        background: var(--primary-50);
      }

      .mini-button:disabled {
        opacity: 0.58;
        cursor: not-allowed;
      }

      .mini-button.danger {
        color: var(--danger-600);
      }

      @media (max-width: 1366px) {
        .builder-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
      }

      @media (max-width: 900px) {
        .builder-grid {
          grid-template-columns: 1fr;
        }

        .section-head,
        .dynamic-row {
          display: grid;
          grid-template-columns: 1fr;
        }

        .span-2 {
          grid-column: auto;
        }
      }
    `
  ]
})
export class RuleCatalogComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  rules: RuleDefinition[] = [];
  showCreate = false;
  filter = '';
  statusFilter: 'ready' | '' = '';
  loading = true;
  busy = false;
  saving = false;
  busyRuleId = '';
  editingRuleId = '';
  error = '';
  message = '';
  draft = this.blankDraft();
  readonly fieldOptions = [
    { value: 'business_key', label: 'Business' },
    { value: 'request_type_key', label: 'Request type' },
    { value: 'vendor_lc', label: 'Vendor' },
    { value: 'din_lc', label: 'DIN' },
    { value: 'min_lc', label: 'MIN' },
    { value: 'manufacturer_lc', label: 'Manufacturer' },
    { value: 'brand_lc', label: 'Brand' },
    { value: 'description_lc', label: 'Description' },
    { value: 'parent_category_lc', label: 'Parent category' },
    { value: 'subcategory_lc', label: 'Sub category' },
    { value: 'usage_num', label: 'Usage' },
    { value: 'meets_criteria_num', label: 'Meets criteria' },
    { value: 'current_action_key', label: 'Current ACTION' },
    { value: 'current_buysmart_key', label: 'Current BuySmart' },
    { value: 'is_compass', label: 'Compass USA' },
    { value: 'is_canada', label: 'Compass Canada' },
    { value: 'is_prf', label: 'PRF' },
    { value: 'is_sorf', label: 'SORF' },
    { value: 'is_srf', label: 'SRF' },
    { value: 'is_one_time', label: 'One-time request' },
    { value: 'is_permanent', label: 'Permanent request' },
    { value: 'is_pantry', label: 'Pantry/APL' },
    { value: 'is_in_catalog', label: 'In catalog' }
  ];
  readonly operatorOptions = [
    { value: 'contains', label: 'contains' },
    { value: 'eq', label: 'equals' },
    { value: 'ne', label: 'does not equal' },
    { value: 'in', label: 'is in' },
    { value: 'not_in', label: 'is not in' },
    { value: 'not_contains', label: 'does not contain' },
    { value: 'blank', label: 'is blank' },
    { value: 'not_blank', label: 'is not blank' },
    { value: 'gt', label: '>' },
    { value: 'ge', label: '>=' },
    { value: 'lt', label: '<' },
    { value: 'le', label: '<=' },
    { value: 'is_true', label: 'is true' },
    { value: 'is_false', label: 'is false' }
  ];
  readonly actionOptions = [
    { value: '', label: 'No change' },
    { value: 'OK', label: 'OK' },
    { value: '1X', label: '1X' },
    { value: 'Use Right', label: 'Use Right' },
    { value: 'Find Alt First', label: 'Find Alt First' },
    { value: 'Cannot Add', label: 'Cannot Add' },
    { value: 'Invalid Information', label: 'Invalid Information' },
    { value: 'Review', label: 'Review' }
  ];
  readonly ifStockOptions = [
    { value: '', label: 'No change' },
    { value: 'OK', label: 'OK' },
    { value: 'Review', label: 'Review' }
  ];
  readonly buysmartOptions = [
    { value: '', label: 'No change' },
    { value: 'Approved', label: 'Approved' },
    { value: 'Denied', label: 'Denied' },
    { value: 'Assigned', label: 'Assigned' },
    { value: 'Review', label: 'Review' }
  ];
  readonly actionItemOptions = [
    { value: 'set_action', label: 'Set ACTION' },
    { value: 'set_if_stock', label: 'Set If In Stock' },
    { value: 'set_buysmart', label: 'Set BuySmart' },
    { value: 'set_review', label: 'Flag for review' },
    { value: 'append_validation', label: 'Add validation' },
    { value: 'add_note', label: 'Add note' },
    { value: 'exclude', label: 'Exclude row' }
  ];

  get selectableActionOptions(): { value: string; label: string }[] {
    return this.actionOptions.filter((option) => option.value);
  }

  get selectableIfStockOptions(): { value: string; label: string }[] {
    return this.ifStockOptions.filter((option) => option.value);
  }

  get selectableBuysmartOptions(): { value: string; label: string }[] {
    return this.buysmartOptions.filter((option) => option.value);
  }

  get filteredRules(): RuleDefinition[] {
    const needle = this.filter.toLowerCase().trim();
    const statusRules = this.statusFilter === 'ready' ? this.rules.filter((rule) => this.isRuleReady(rule)) : this.rules;
    const rules = needle ? statusRules.filter((rule) => JSON.stringify(rule).toLowerCase().includes(needle)) : statusRules;
    return [...rules].sort((a, b) => this.rulePriority(a) - this.rulePriority(b) || a.ruleId.localeCompare(b.ruleId, undefined, { numeric: true }));
  }

  get isEditing(): boolean {
    return Boolean(this.editingRuleId);
  }

  get executableCount(): number {
    return this.rules.flatMap((rule) => rule.variants).filter((variant) => variant.enabled && variant.isExecutable && variant.status === 'approved').length;
  }

  get displayRuleCount(): number {
    return this.rules.length || READY_HEALTH.ruleCount || 0;
  }

  get displayExecutableCount(): number {
    return this.executableCount || READY_HEALTH.executableVariantCount || 0;
  }

  get manualCount(): number {
    return this.rules.flatMap((rule) => rule.variants).filter((variant) => !variant.isExecutable).length;
  }

  get displayManualCount(): number {
    return this.manualCount || 27;
  }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe((params) => {
      this.statusFilter = params.get('status') === 'ready' ? 'ready' : '';
    });
    void this.load();
  }

  clearStatusFilter(): void {
    void this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { status: null },
      queryParamsHandling: 'merge'
    });
  }

  async load(): Promise<void> {
    this.loading = true;
    this.error = '';
    try {
      this.rules = await this.api.listRules();
      this.message = '';
    } catch (error) {
      this.error = this.errorMessage(error);
    } finally {
      this.loading = false;
    }
  }

  async refreshRules(): Promise<void> {
    this.busy = true;
    this.message = '';
    this.error = '';
    try {
      this.rules = await this.api.listRules();
      this.message = `Rules refreshed. ${this.rules.length} saved rules, ${this.executableCount} ready to run.`;
    } catch (error) {
      this.error = this.errorMessage(error);
    } finally {
      this.busy = false;
      this.loading = false;
    }
  }

  openCreate(): void {
    if (this.showCreate) {
      this.editingRuleId = '';
      this.resetDraft();
      this.showCreate = false;
      return;
    }
    this.editingRuleId = '';
    this.resetDraft();
    this.showCreate = true;
    this.message = '';
    this.error = '';
  }

  editRule(rule: RuleDefinition): void {
    this.editingRuleId = rule.ruleId;
    this.draft = this.draftFromRule(rule);
    this.showCreate = true;
    this.message = '';
    this.error = '';
  }

  async saveRule(): Promise<void> {
    this.message = '';
    this.error = '';
    if (!this.draft.name.trim()) {
      this.error = 'Rule name is required.';
      return;
    }
    if (!this.hasDraftAction()) {
      this.error = 'Add at least one action before saving the rule.';
      return;
    }
    const priority = Number(this.draft.executionPriority);
    if (!Number.isInteger(priority) || priority < 1) {
      this.error = 'Rule priority must be a positive whole number.';
      return;
    }
    this.saving = true;
    try {
      const result = this.isEditing
        ? await this.api.updateRule(this.editingRuleId, this.requestDraft())
        : await this.api.createRule(this.requestDraft());
      this.rules = result.rules;
      this.message = this.isEditing
        ? `${result.rule.ruleId} updated. ${this.executableFor(result.rule)} ready variant saved.`
        : `${result.rule.ruleId} created. ${this.executableFor(result.rule)} ready variant saved.`;
      this.showCreate = false;
      this.editingRuleId = '';
      this.resetDraft();
    } catch (error) {
      this.error = this.errorMessage(error);
    } finally {
      this.saving = false;
    }
  }

  async toggleRule(rule: RuleDefinition): Promise<void> {
    this.busyRuleId = rule.ruleId;
    this.message = '';
    this.error = '';
    try {
      const enable = this.isRuleDisabled(rule);
      const result = await this.api.setRuleEnabled(rule.ruleId, enable);
      this.rules = result.rules;
      this.message = `${rule.ruleId} ${enable ? 'enabled' : 'disabled'}.`;
    } catch (error) {
      this.error = this.errorMessage(error);
    } finally {
      this.busyRuleId = '';
    }
  }

  executableFor(rule: RuleDefinition): number {
    return rule.variants.filter((variant) => variant.enabled && variant.isExecutable && variant.status === 'approved').length;
  }

  isRuleReady(rule: RuleDefinition): boolean {
    return this.executableFor(rule) > 0;
  }

  rulePriority(rule: RuleDefinition): number {
    return rule.variants.map((variant) => variant.executionPriority).sort((a, b) => a - b)[0] ?? 999999;
  }

  runtimeKindLabel(rule: RuleDefinition): string {
    const kind = rule.variants[0]?.runtimeKind || 'row_rule';
    if (kind === 'validation_rule') return 'Validation';
    if (kind === 'buysmart_rule') return 'BuySmart';
    if (kind === 'downstream_rule') return 'Downstream';
    return 'Row';
  }

  fieldFilter(rule: RuleDefinition): string {
    return rule.variants[0]?.source?.compiledLogic?.fieldFilterLogic || rule.variants[0]?.source?.fieldFilterLogic || rule.variants[0]?.description || rule.name;
  }

  aggregateLogic(rule: RuleDefinition): string {
    return rule.variants[0]?.source?.compiledLogic?.aggregateLogic || rule.variants[0]?.source?.aggregateLogic || 'No aggregate action';
  }

  automationLabel(rule: RuleDefinition): string {
    if (this.isRuleDisabled(rule)) return 'Disabled';
    if (rule.automationLevel === 'alpha') return 'Ready';
    if (rule.automationLevel === 'guided') return 'Guided';
    if (rule.automationLevel === 'manual') return 'Manual';
    return 'Reference';
  }

  statusClass(rule: RuleDefinition): string {
    if (this.isRuleDisabled(rule)) return 'tag bad';
    if (rule.automationLevel === 'alpha') return 'tag good';
    if (rule.automationLevel === 'guided') return 'tag warn';
    return 'tag info';
  }

  isRuleDisabled(rule: RuleDefinition): boolean {
    return rule.status === 'disabled' || rule.variants.every((variant) => !variant.enabled || variant.status === 'disabled');
  }

  operatorNeedsValue(op: string): boolean {
    return !['blank', 'not_blank', 'is_true', 'is_false'].includes(op);
  }

  addFilter(): void {
    this.draft.filters = [...this.currentFilters(), this.blankFilter()];
    this.draft.filter = this.draft.filters[0];
  }

  removeFilter(index: number): void {
    const next = this.currentFilters().filter((_, itemIndex) => itemIndex !== index);
    this.draft.filters = next.length ? next : [this.blankFilter()];
    this.draft.filter = this.draft.filters[0];
  }

  normalizeFilterValue(filter: RuleFilterRequest): void {
    if (!this.operatorNeedsValue(filter.op)) filter.value = '';
  }

  addActionItem(): void {
    this.draft.actionItems = [...this.currentActionItems(), this.blankActionItem()];
    this.draft.actions = this.legacyActionsFromItems(this.draft.actionItems);
  }

  removeActionItem(index: number): void {
    const next = this.currentActionItems().filter((_, itemIndex) => itemIndex !== index);
    this.draft.actionItems = next.length ? next : [this.blankActionItem()];
    this.draft.actions = this.legacyActionsFromItems(this.draft.actionItems);
  }

  normalizeActionItem(item: RuleActionItemRequest): void {
    if (item.type === 'set_action' && !item.value) item.value = this.selectableActionOptions[0]?.value ?? 'OK';
    if (item.type === 'set_if_stock' && !item.value) item.value = this.selectableIfStockOptions[0]?.value ?? 'OK';
    if (item.type === 'set_buysmart' && !item.value) item.value = this.selectableBuysmartOptions[0]?.value ?? 'Approved';
    if (item.type === 'set_review') item.value = true;
    if (item.type === 'exclude' && !item.reason) item.reason = '';
    if (!['append_validation', 'add_note', 'set_action', 'set_if_stock', 'set_buysmart'].includes(item.type)) item.value = item.type === 'set_review' ? true : undefined;
    if (item.type !== 'exclude') item.reason = undefined;
  }

  resetDraft(): void {
    this.draft = this.blankDraft();
  }

  resetOrCancelDraft(): void {
    this.resetDraft();
    if (this.isEditing) {
      this.editingRuleId = '';
      this.showCreate = false;
    }
  }

  private blankDraft(): RuleCreateRequest {
    const filter = this.blankFilter();
    const actionItem = this.blankActionItem('set_buysmart', 'Review');
    return {
      ruleId: '',
      name: '',
      ruleGroup: 'User Managed',
      businessScope: 'All',
      requestTypes: 'PRF, SORF, SRF',
      executionPriority: this.nextPriority(),
      filter,
      filters: [filter],
      filterJoin: 'all',
      actions: this.legacyActionsFromItems([actionItem]),
      actionItems: [actionItem],
      enabled: true,
      stopProcessing: false,
      notes: ''
    };
  }

  private draftFromRule(rule: RuleDefinition): RuleCreateRequest {
    const variant = rule.variants[0];
    return {
      ruleId: rule.ruleId,
      name: rule.name,
      ruleGroup: rule.ruleGroup || 'User Managed',
      businessScope: rule.businessScope || 'All',
      requestTypes: rule.requestTypes.join(', ') || 'PRF, SORF, SRF',
      executionPriority: variant?.executionPriority ?? this.nextPriority(),
      filter: this.filterFromPredicate(variant?.predicateJson),
      filters: this.filtersFromPredicate(variant?.predicateJson),
      filterJoin: this.filterJoinFromPredicate(variant?.predicateJson),
      actions: this.actionsFromVariant(variant?.actionJson),
      actionItems: this.actionItemsFromVariant(variant?.actionJson),
      enabled: !this.isRuleDisabled(rule),
      stopProcessing: Boolean(variant?.stopProcessing),
      notes: rule.notes || ''
    };
  }

  private blankFilter(): RuleFilterRequest {
    return {
      field: 'vendor_lc',
      op: 'contains',
      value: ''
    };
  }

  private filterFromPredicate(value: unknown): RuleFilterRequest {
    return this.filtersFromPredicate(value)[0] ?? this.blankFilter();
  }

  private filtersFromPredicate(value: unknown): RuleFilterRequest[] {
    const predicate = this.objectValue(value);
    const predicates = Array.isArray(predicate['all'])
      ? (predicate['all'] as unknown[])
      : Array.isArray(predicate['any'])
        ? (predicate['any'] as unknown[])
        : [predicate];
    const filters = predicates.map((item) => this.filterRowFromPredicate(item)).filter(Boolean) as RuleFilterRequest[];
    return filters.length ? filters : [this.blankFilter()];
  }

  private filterJoinFromPredicate(value: unknown): 'all' | 'any' {
    const predicate = this.objectValue(value);
    return Array.isArray(predicate['any']) ? 'any' : 'all';
  }

  private filterRowFromPredicate(value: unknown): RuleFilterRequest | null {
    const predicate = this.objectValue(value);
    if (!('field' in predicate) || !('op' in predicate)) return null;
    const field = this.fieldOptions.some((option) => option.value === predicate['field']) ? String(predicate['field']) : 'vendor_lc';
    const op = this.operatorOptions.some((option) => option.value === predicate['op']) ? String(predicate['op']) : 'contains';
    return {
      field,
      op,
      value: this.draftFilterValue(predicate['value'])
    };
  }

  private actionsFromVariant(value: unknown): RuleCreateRequest['actions'] {
    return this.legacyActionsFromItems(this.actionItemsFromVariant(value));
  }

  private actionItemsFromVariant(value: unknown): RuleActionItemRequest[] {
    const items: RuleActionItemRequest[] = [];
    const actions = Array.isArray(value) ? (value as Record<string, unknown>[]) : [];
    for (const action of actions) {
      const type = String(action['type'] ?? '');
      if (type === 'exclude') items.push({ type, reason: this.stringValue(action['reason']) });
      if (type === 'set_action') items.push({ type, value: this.stringValue(action['value']) });
      if (type === 'set_if_stock') items.push({ type, value: this.stringValue(action['value']) });
      if (type === 'set_buysmart') items.push({ type, value: this.stringValue(action['value']) });
      if (type === 'set_review') items.push({ type, value: true });
      if (type === 'append_validation') items.push({ type, value: this.stringValue(action['value']) });
      if (type === 'add_note') items.push({ type, value: this.stringValue(action['value']) });
    }
    return items.length ? items : [this.blankActionItem()];
  }

  private blankActionItem(type: RuleActionItemRequest['type'] = 'set_action', value = ''): RuleActionItemRequest {
    const item: RuleActionItemRequest = { type, value };
    this.normalizeActionItem(item);
    return item;
  }

  private legacyActionsFromItems(items: RuleActionItemRequest[]): RuleCreateRequest['actions'] {
    const draft: RuleCreateRequest['actions'] = {
      action: '',
      ifInStockAction: '',
      buysmartAction: '',
      review: false,
      validation: '',
      note: '',
      exclude: false,
      excludeReason: ''
    };
    for (const action of items) {
      const type = action.type;
      if (type === 'exclude') {
        draft.exclude = true;
        draft.excludeReason = this.stringValue(action.reason);
      }
      if (type === 'set_action') draft.action = this.stringValue(action.value);
      if (type === 'set_if_stock') draft.ifInStockAction = this.stringValue(action.value);
      if (type === 'set_buysmart') draft.buysmartAction = this.stringValue(action.value);
      if (type === 'set_review') draft.review = true;
      if (type === 'append_validation') draft.validation = this.stringValue(action.value);
      if (type === 'add_note') draft.note = this.stringValue(action.value);
    }
    return draft;
  }

  private currentFilters(): RuleFilterRequest[] {
    return this.draft.filters?.length ? this.draft.filters : [this.draft.filter ?? this.blankFilter()];
  }

  private currentActionItems(): RuleActionItemRequest[] {
    return this.draft.actionItems?.length ? this.draft.actionItems : this.actionItemsFromLegacyActions(this.draft.actions);
  }

  private actionItemsFromLegacyActions(actions: RuleCreateRequest['actions']): RuleActionItemRequest[] {
    const items: RuleActionItemRequest[] = [];
    if (actions.action) items.push({ type: 'set_action', value: actions.action });
    if (actions.ifInStockAction) items.push({ type: 'set_if_stock', value: actions.ifInStockAction });
    if (actions.buysmartAction) items.push({ type: 'set_buysmart', value: actions.buysmartAction });
    if (actions.review) items.push({ type: 'set_review', value: true });
    if (actions.validation) items.push({ type: 'append_validation', value: actions.validation });
    if (actions.note) items.push({ type: 'add_note', value: actions.note });
    if (actions.exclude) items.push({ type: 'exclude', reason: actions.excludeReason });
    return items.length ? items : [this.blankActionItem()];
  }

  private objectValue(value: unknown): Record<string, unknown> {
    return value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
  }

  private draftFilterValue(value: unknown): string | number | boolean {
    if (Array.isArray(value)) return value.map((item) => this.stringValue(item)).filter(Boolean).join(', ');
    if (typeof value === 'number' || typeof value === 'boolean') return value;
    return this.stringValue(value);
  }

  private stringValue(value: unknown): string {
    return value === undefined || value === null ? '' : String(value);
  }

  private requestDraft(): RuleCreateRequest {
    const draft = structuredClone(this.draft);
    draft.filters = this.currentFilters().map((filter) => ({ ...filter }));
    draft.filters.forEach((filter) => {
      if (!this.operatorNeedsValue(filter.op)) filter.value = '';
    });
    draft.filter = draft.filters[0];
    draft.filterJoin = draft.filterJoin === 'any' ? 'any' : 'all';
    draft.actionItems = this.currentActionItems().map((item) => {
      const next = { ...item };
      this.normalizeActionItem(next);
      return next;
    });
    draft.actions = this.legacyActionsFromItems(draft.actionItems);
    draft.executionPriority = Number(draft.executionPriority);
    return draft;
  }

  private nextPriority(): number {
    return Math.max(900000, ...this.rules.flatMap((rule) => rule.variants.map((variant) => variant.executionPriority + 10)));
  }

  private hasDraftAction(): boolean {
    return this.currentActionItems().some((action) => {
      if (action.type === 'set_review' || action.type === 'exclude') return true;
      return Boolean(this.stringValue(action.value).trim());
    });
  }

  private errorMessage(error: unknown): string {
    if (typeof error === 'object' && error && 'error' in error) {
      const wrapped = error as { error?: { error?: string; message?: string } };
      return wrapped.error?.error || wrapped.error?.message || 'Rule catalog failed.';
    }
    return error instanceof Error ? error.message : 'Rule catalog failed.';
  }
}
