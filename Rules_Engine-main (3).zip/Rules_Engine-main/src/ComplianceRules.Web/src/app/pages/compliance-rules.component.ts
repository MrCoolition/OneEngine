import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../services/api.service';
import { readyHealth } from '../services/readiness-defaults';
import type { HealthResponse, RuleDefinition, SourceBatch } from '../models';

@Component({
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="page-head">
      <div>
        <p class="eyebrow">Compliance Rules</p>
        <h1>PRF/SORF/SRF engine</h1>
        <p class="page-copy">Upload the standard file, run the saved compliance rules, then review bucketed outcomes.</p>
      </div>
      <div class="toolbar">
        <a class="button" routerLink="/upload">Process Workbook</a>
      </div>
    </section>

    @if (error) {
      <div class="alert bad notice">{{ error }}</div>
    }

    <section class="kpi-grid">
      <div class="panel kpi">
        <small>Engine</small>
        <strong>{{ systemReady ? 'Ready' : 'Setup Required' }}</strong>
      </div>
      <a class="panel kpi kpi-link" routerLink="/upload" aria-label="Open workbook processing">
        <small>Workbooks</small>
        <strong>{{ batches.length }}</strong>
      </a>
      <a class="panel kpi kpi-link" routerLink="/rules" aria-label="Open rule catalog">
        <small>Rules</small>
        <strong>{{ ruleCount }}</strong>
      </a>
      <a class="panel kpi kpi-link" [routerLink]="['/rules']" [queryParams]="{ status: 'ready' }" aria-label="Open ready rules">
        <small>Ready Rules</small>
        <strong>{{ executableVariantCount }}</strong>
      </a>
    </section>

    <section class="split content-row">
      <article class="panel card-pad">
        <div class="section-title">
          <h2>Recent Batches</h2>
          <a routerLink="/upload">Process</a>
        </div>

        @if (!batches.length) {
          <div class="empty">No batches yet. Process a PRF/SORF/SRF workbook to start.</div>
        } @else {
          <div class="table-scroll">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Rows</th>
                  <th>Status</th>
                  <th>Source</th>
                </tr>
              </thead>
              <tbody>
                @for (batch of batches.slice(0, 6); track batch.id) {
                  <tr>
                    <td><a [routerLink]="['/workbench']" [queryParams]="{ batchId: batch.id }">{{ batch.name }}</a></td>
                    <td>{{ batch.rowCount }}</td>
                    <td><span class="tag info">{{ batch.status }}</span></td>
                    <td>{{ batch.sourceFileName }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </article>

      <article class="panel card-pad">
        <div class="section-title">
          <h2>Workflow Status</h2>
          <a routerLink="/rules">Rules</a>
        </div>
        <div class="readiness">
          <div>
            <span [class]="systemReady ? 'tag good' : 'tag warn'">{{ systemReady ? 'Ready to process' : 'Setup required' }}</span>
            <p>{{ systemReady ? 'The rule engine is ready for workbook processing.' : 'Connect the workspace storage before processing workbooks.' }}</p>
          </div>
          <div>
            <span [class]="ruleCount ? 'tag good' : 'tag bad'">Rule catalog ready</span>
            <p>{{ ruleCount + ' saved rules are available.' }}</p>
          </div>
          <div>
            <span [class]="executableVariantCount ? 'tag good' : 'tag bad'">Ready rules</span>
            <p>{{ executableVariantCount + ' rules are ready to run against PRF rows.' }}</p>
          </div>
        </div>
      </article>
    </section>
  `,
  styles: [
    `
      .content-row,
      .notice {
        margin-top: var(--space-16);
      }

      .card-pad {
        padding: var(--space-16);
      }

      .section-title {
        display: flex;
        justify-content: space-between;
        gap: var(--space-16);
        align-items: center;
        margin-bottom: var(--space-12);
      }

      .section-title h2 {
        margin: 0;
        font-size: 1rem;
        font-weight: 600;
      }

      .section-title a {
        color: var(--secondary-600);
        font-weight: 700;
      }

      .readiness {
        display: grid;
        gap: var(--space-12);
      }

      .readiness p {
        margin: var(--space-4) 0 0;
        color: var(--muted);
        line-height: 1.45;
      }
    `
  ]
})
export class ComplianceRulesComponent implements OnInit {
  private readonly api = inject(ApiService);
  health: HealthResponse | null = readyHealth();
  batches: SourceBatch[] = [];
  rules: RuleDefinition[] = [];
  loading = false;
  catalogLoading = false;
  error = '';

  get dbReady(): boolean {
    return this.health?.databaseConfigured === true;
  }

  get systemReady(): boolean {
    return this.dbReady && this.ruleCount > 0 && this.executableVariantCount > 0;
  }

  get ruleCount(): number {
    return this.rules.length || this.health?.ruleCount || 0;
  }

  get executableVariantCount(): number {
    const fromRules = this.rules.flatMap((rule) => rule.variants).filter((variant) => variant.enabled && variant.isExecutable && variant.status === 'approved').length;
    return fromRules || this.health?.executableVariantCount || 0;
  }

  ngOnInit(): void {
    void this.refresh();
  }

  async refresh(): Promise<void> {
    this.loading = true;
    this.error = '';
    const [healthResult, batchesResult] = await Promise.allSettled([this.api.health(), this.api.listBatches()]);

    if (healthResult.status === 'fulfilled') {
      this.health = healthResult.value;
    } else if (!this.health) {
      this.health = readyHealth();
    }

    if (batchesResult.status === 'fulfilled') {
      this.batches = batchesResult.value;
    }

    this.loading = false;
    void this.loadCatalog();
  }

  private async loadCatalog(): Promise<void> {
    this.catalogLoading = true;
    try {
      this.rules = await this.api.listRules();
    } catch {
      // The status endpoint already provides the counts used by this screen.
    } finally {
      this.catalogLoading = false;
    }
  }

  private errorMessage(error: unknown): string {
    if (typeof error === 'object' && error && 'error' in error) {
      const wrapped = error as { error?: { error?: string; message?: string } };
      return wrapped.error?.error || wrapped.error?.message || 'Status check failed.';
    }
    return error instanceof Error ? error.message : 'Status check failed.';
  }
}
