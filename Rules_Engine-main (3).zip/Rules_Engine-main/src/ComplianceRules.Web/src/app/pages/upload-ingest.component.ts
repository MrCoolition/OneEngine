import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../services/api.service';
import { BatchSelectionService } from '../services/batch-selection.service';
import { readyHealth } from '../services/readiness-defaults';
import type { BatchSummary, HealthResponse, RuleDefinition, RuleRun } from '../models';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <section class="page-title">
      <div>
        <p>Process</p>
        <h1>Run PRF workbook</h1>
        <p class="page-copy">Upload the standard PRF/SORF/SRF file. The engine applies the saved compliance rules and returns bucketed outcomes.</p>
      </div>
      <div class="status-strip">
        <span [class]="readyForProcessing ? 'tag good' : 'tag warn'">{{ readyForProcessing ? 'Ready' : 'Setup Required' }}</span>
        <span [class]="rulesReady ? 'tag good' : 'tag bad'">{{ ruleCount }} rules</span>
        <span [class]="executableVariantCount ? 'tag good' : 'tag bad'">{{ executableVariantCount }} ready</span>
      </div>
    </section>

    <section class="panel workflow-panel">
      <div class="workflow-grid">
        <div class="workbook-pane">
          <h2>Workbook</h2>
          <div class="form-grid">
            <label class="field">
              <span>Batch name</span>
              <input [(ngModel)]="batchName" placeholder="Daily PRF/SORF/SRF">
            </label>
            <label class="field">
              <span>Reporting date</span>
              <input type="date" [(ngModel)]="reportingDate">
            </label>
          </div>

          <label class="drop">
            <input type="file" accept=".xlsx" (change)="onSourceFile($event)">
            <strong>{{ sourceFile?.name || 'Choose workbook' }}</strong>
            <span>.xlsx PRF/SORF/SRF source file</span>
          </label>

          <div class="actions">
            <button class="button" (click)="processWorkbook()" [disabled]="busy || !sourceFile || !readyForProcessing">
              {{ busy ? busyLabel : 'Process Workbook' }}
            </button>
            @if (latestBatchId) {
              <a class="button secondary" routerLink="/workbench" [queryParams]="{ batchId: latestBatchId }">Review Rows</a>
              <button class="button ghost" (click)="export('xlsx')">Export to Excel</button>
              <button class="button ghost" (click)="export('manual')">Manual Excel</button>
            }
          </div>
        </div>

        <aside class="engine-pane">
          <h2>Run Status</h2>
          <div class="engine-row">
            <span>Engine</span>
            <strong>{{ dbReady ? 'Ready' : 'Setup Required' }}</strong>
          </div>
          <div class="engine-row">
            <span>Rules</span>
            <strong>{{ rulesReady ? 'Ready' : 'Empty' }}</strong>
          </div>
          <div class="engine-row">
            <span>Source</span>
            <strong>Saved DAF catalog</strong>
          </div>

          @if (readinessError) {
            <div class="alert bad">{{ readinessError }}</div>
          } @else if (!dbReady) {
            <div class="alert warn">Connect workspace storage before processing a workbook.</div>
          } @else if (!rulesReady) {
            <div class="alert bad">No runnable rules are loaded. Contact support.</div>
          } @else if (catalogLoading) {
            <div class="alert good">Ready to process. Finalizing catalog details in the background.</div>
          } @else {
            <div class="alert good">Ready to process against {{ executableVariantCount }} rules.</div>
          }
        </aside>
      </div>
    </section>

    @if (run) {
      <section class="kpi-grid result-kpis">
        <article class="panel kpi"><small>Input Rows</small><strong>{{ run.inputRowCount }}</strong></article>
        <article class="panel kpi"><small>Changed Rows</small><strong>{{ run.changedRowCount }}</strong></article>
        <article class="panel kpi"><small>Review Rows</small><strong>{{ run.reviewRowCount }}</strong></article>
        <article class="panel kpi"><small>Status</small><strong>{{ run.status }}</strong></article>
      </section>
    }

    @if (summary) {
      <section class="process-buckets">
        @for (bucket of summary.bucketSummaries; track bucket.id) {
          <article
            class="panel quick-bucket"
            [class.good]="bucket.tone === 'good'"
            [class.warn]="bucket.tone === 'warn'"
            [class.bad]="bucket.tone === 'bad'"
            [class.info]="bucket.tone === 'info'"
            [class.dark]="bucket.tone === 'dark'"
          >
            <div>
              <h2>{{ bucket.label }}</h2>
              <p>{{ bucket.description }}</p>
            </div>
            <strong>{{ bucket.count }}</strong>
            <a [routerLink]="['/workbench']" [queryParams]="{ batchId: latestBatchId, bucket: bucket.id }">Review</a>
          </article>
        }
      </section>

      <section class="split result-row">
        <article class="panel bucket-card">
          <h2>Outcome Mix</h2>
          @for (entry of entries(summary.outcomeCounts); track entry[0]) {
            <div class="bar-line">
              <span>{{ entry[0] }}</span>
              <div class="bar"><i [style.width.%]="percent(entry[1], summary.rowCount)"></i></div>
              <strong>{{ entry[1] }}</strong>
            </div>
          }
        </article>
        <article class="panel bucket-card">
          <h2>Request Mix</h2>
          @for (entry of entries(summary.typeCounts); track entry[0]) {
            <div class="bar-line accent">
              <span>{{ entry[0] }}</span>
              <div class="bar"><i [style.width.%]="percent(entry[1], summary.rowCount)"></i></div>
              <strong>{{ entry[1] }}</strong>
            </div>
          }
        </article>
      </section>
    }

    @if (message) {
      <pre class="panel output">{{ message }}</pre>
    }
  `,
  styles: [
    `
      .status-strip {
        display: flex;
        flex-wrap: wrap;
        gap: var(--space-8);
        justify-content: flex-end;
      }

      .workflow-panel {
        padding: var(--space-16);
      }

      .workflow-grid {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 280px;
        gap: var(--space-16);
      }

      .workbook-pane h2,
      .engine-pane h2,
      .bucket-card h2 {
        margin: 0 0 var(--space-12);
        font-size: 1rem;
        font-weight: 600;
      }

      .form-grid {
        display: grid;
        grid-template-columns: minmax(220px, 1fr) 180px;
        gap: var(--space-12);
      }

      .drop {
        display: grid;
        place-items: center;
        gap: var(--space-4);
        min-height: 7rem;
        margin: var(--space-16) 0;
        border: 1px dashed var(--neutral-300);
        border-radius: var(--radius-md);
        background: var(--neutral-50);
        color: var(--muted);
        text-align: center;
        cursor: pointer;
      }

      .drop:hover {
        border-color: var(--primary-500);
        background: var(--primary-50);
      }

      .drop input {
        display: none;
      }

      .drop strong {
        color: var(--ink);
        max-width: 100%;
        overflow-wrap: anywhere;
      }

      .drop span {
        font-size: 0.875rem;
      }

      .engine-pane {
        display: grid;
        align-content: start;
        gap: var(--space-12);
        padding-left: var(--space-16);
        border-left: 1px solid var(--line);
      }

      .engine-row {
        display: flex;
        justify-content: space-between;
        gap: var(--space-16);
        padding-bottom: var(--space-8);
        border-bottom: 1px solid var(--line);
        font-size: 0.875rem;
      }

      .engine-row span {
        color: var(--muted);
      }

      .engine-row strong {
        text-align: right;
      }

      .result-kpis,
      .process-buckets,
      .result-row,
      .output {
        margin-top: var(--space-16);
      }

      .process-buckets {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: var(--space-12);
      }

      .quick-bucket {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: var(--space-8) var(--space-12);
        padding: var(--space-16);
        border-top: 4px solid var(--primary);
      }

      .quick-bucket.good {
        border-top-color: var(--good);
      }

      .quick-bucket.warn {
        border-top-color: var(--warn);
      }

      .quick-bucket.bad {
        border-top-color: var(--danger);
      }

      .quick-bucket.info {
        border-top-color: var(--secondary-500);
      }

      .quick-bucket h2,
      .quick-bucket p {
        margin: 0;
      }

      .quick-bucket h2 {
        font-size: 1rem;
        font-weight: 600;
      }

      .quick-bucket p {
        margin-top: var(--space-4);
        color: var(--muted);
        line-height: 1.35;
      }

      .quick-bucket strong {
        font-size: 1.75rem;
        font-weight: 600;
        line-height: 1;
      }

      .quick-bucket a {
        grid-column: 1 / -1;
        justify-self: end;
        color: var(--secondary-600);
        font-weight: 700;
      }

      .bucket-card {
        padding: var(--space-16);
      }

      .bar-line {
        display: grid;
        grid-template-columns: 150px minmax(0, 1fr) 48px;
        align-items: center;
        gap: var(--space-12);
        margin: var(--space-12) 0;
      }

      .bar-line span {
        color: var(--muted);
        font-weight: 600;
        overflow-wrap: anywhere;
      }

      .bar {
        height: 0.56rem;
        border-radius: var(--radius-pill);
        background: var(--neutral-100);
        overflow: hidden;
      }

      .bar i {
        display: block;
        height: 100%;
        min-width: 2px;
        background: var(--primary);
      }

      .bar-line.accent .bar i {
        background: var(--data-1);
      }

      .output {
        padding: var(--space-16);
        white-space: pre-wrap;
        overflow-x: auto;
      }

      @media (max-width: 900px) {
        .workflow-grid,
        .form-grid,
        .process-buckets {
          grid-template-columns: 1fr;
        }

        .engine-pane {
          padding-left: 0;
          border-left: 0;
          border-top: 1px solid var(--line);
          padding-top: var(--space-16);
        }
      }
    `
  ]
})
export class UploadIngestComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly batchSelection = inject(BatchSelectionService);
  health: HealthResponse | null = readyHealth();
  rules: RuleDefinition[] = [];
  loadingReadiness = false;
  catalogLoading = false;
  readinessError = '';
  busy = false;
  busyLabel = '';
  message = '';
  sourceFile: File | null = null;
  reportingDate = new Date().toISOString().slice(0, 10);
  batchName = 'Daily PRF/SORF/SRF';
  latestBatchId = '';
  run: RuleRun | null = null;
  summary: BatchSummary | null = null;

  get dbReady(): boolean {
    return this.health?.databaseConfigured === true;
  }

  get executableVariantCount(): number {
    const fromRules = this.rules.flatMap((rule) => rule.variants).filter((variant) => variant.enabled && variant.isExecutable && variant.status === 'approved').length;
    return fromRules || this.health?.executableVariantCount || 0;
  }

  get ruleCount(): number {
    return this.rules.length || this.health?.ruleCount || 0;
  }

  get rulesReady(): boolean {
    return this.ruleCount > 0 && this.executableVariantCount > 0;
  }

  get readyForProcessing(): boolean {
    return this.dbReady && this.rulesReady;
  }

  ngOnInit(): void {
    void this.refreshReadiness();
  }

  onSourceFile(event: Event): void {
    this.sourceFile = (event.target as HTMLInputElement).files?.[0] ?? null;
    this.run = null;
    this.summary = null;
    this.message = '';
  }

  async processWorkbook(): Promise<void> {
    if (!this.sourceFile || !this.readyForProcessing) return;
    this.busy = true;
    try {
      this.busyLabel = 'Uploading';
      const upload = await this.api.uploadWorkbook(this.sourceFile, this.reportingDate, this.batchName);
      this.latestBatchId = upload.batchId;
      this.batchSelection.save(upload.batchId);

      this.busyLabel = 'Executing rules';
      const result = await this.api.runBatch(upload.batchId, false);
      this.run = result.run;

      this.busyLabel = 'Building buckets';
      this.summary = await this.api.batchSummary(upload.batchId);
      this.message = upload.warnings.length ? upload.warnings.join('\n') : '';
    } catch (error) {
      this.message = this.errorMessage(error);
    } finally {
      this.busy = false;
      this.busyLabel = '';
    }
  }

  export(format: 'csv' | 'xlsx' | 'manual'): void {
    if (this.latestBatchId) this.api.exportBatch(this.latestBatchId, format);
  }

  entries(record: Record<string, number>): [string, number][] {
    return Object.entries(record).sort((a, b) => b[1] - a[1]);
  }

  percent(value: number, total: number): number {
    return total ? Math.max((value / total) * 100, 2) : 0;
  }

  private async refreshReadiness(): Promise<void> {
    this.loadingReadiness = true;
    this.readinessError = '';
    try {
      this.health = await this.api.health();
    } catch {
      if (!this.health) this.health = readyHealth();
    } finally {
      this.loadingReadiness = false;
    }
    if (this.readyForProcessing) void this.loadCatalog();
  }

  private async loadCatalog(): Promise<void> {
    this.catalogLoading = true;
    try {
      this.rules = await this.api.listRules();
    } catch {
      // The status endpoint already carries the counts needed for processing.
    } finally {
      this.catalogLoading = false;
    }
  }

  private errorMessage(error: unknown): string {
    if (typeof error === 'object' && error && 'error' in error) {
      const wrapped = error as { error?: { error?: string; message?: string } };
      return wrapped.error?.error || wrapped.error?.message || 'Processing failed.';
    }
    return error instanceof Error ? error.message : 'Processing failed.';
  }
}
