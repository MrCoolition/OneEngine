import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';
import { BatchSelectionService } from '../services/batch-selection.service';
import type { SourceBatch, WorkflowRow } from '../models';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="page-title">
      <div>
        <p>Analyst Workbench</p>
        <h1>Review workflow rows</h1>
      </div>
      <div class="toolbar">
        <button class="button" (click)="exportExcel()" [disabled]="!selectedBatchId">Export to Excel</button>
        <button class="button secondary" (click)="exportManualExcel()" [disabled]="!selectedBatchId">Manual Excel</button>
        <button class="button secondary" (click)="runRulesAndRefresh()" [disabled]="runningRules || loadingRows || !selectedBatchId">
          {{ runningRules ? 'Running Rules' : 'Run Rules & Refresh' }}
        </button>
        <button class="button ghost" (click)="loadRows()" [disabled]="loadingRows || !selectedBatchId">
          {{ loadingRows ? 'Refreshing' : 'Refresh Rows' }}
        </button>
      </div>
    </section>

    @if (message) {
      <div class="alert info notice">{{ message }}</div>
    }

    <section class="panel filters">
      <div class="toolbar">
        <label class="field">
          <span>Batch</span>
          <select [(ngModel)]="selectedBatchId" (change)="onBatchChange()" [disabled]="loadingBatches || !batches.length">
            <option value="">{{ loadingBatches ? 'Loading batches' : batches.length ? 'Select batch' : 'No batches' }}</option>
            @for (batch of batches; track batch.id) {
              <option [value]="batch.id">{{ batch.name }}</option>
            }
          </select>
        </label>
        <label class="field search">
          <span>Search</span>
          <input [(ngModel)]="search" (keyup.enter)="loadRows()" placeholder="Case, vendor, DIN, description">
        </label>
        <label class="field">
          <span>Needs review</span>
          <select [(ngModel)]="needsReview" (change)="loadRows()">
            <option value="">All</option>
            <option value="true">Review</option>
            <option value="false">Ready</option>
          </select>
        </label>
        <label class="field">
          <span>Bucket</span>
          <select [(ngModel)]="bucket" (change)="loadRows()">
            <option value="">All buckets</option>
            @for (option of bucketOptions; track option.id) {
              <option [value]="option.id">{{ option.label }}</option>
            }
          </select>
        </label>
        <button class="button" (click)="loadRows()" [disabled]="!selectedBatchId">Apply</button>
      </div>
    </section>

    <section class="split workbench">
      <article class="panel table-card">
        @if (loadingBatches) {
          <div class="empty">Loading available batches.</div>
        } @else if (loadingRows) {
          <div class="empty">Loading rows for the selected batch.</div>
        } @else if (!selectedBatchId) {
          <div class="empty">No batch selected.</div>
        } @else {
          <div class="table-meta">{{ total }} rows</div>
          <div class="table-scroll">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Case</th>
                  <th>Business</th>
                  <th>Type</th>
                  <th>Vendor</th>
                  <th>Action</th>
                  <th>BuySmart</th>
                  <th>Bucket</th>
                  <th>Outcome</th>
                </tr>
              </thead>
              <tbody>
                @for (row of rows; track row.id) {
                  <tr (click)="selectRow(row)" [class.selected]="selected?.id === row.id">
                    <td>{{ row.caseNumber }}</td>
                    <td>{{ row.business }}</td>
                    <td>{{ row.requestType }}</td>
                    <td>{{ row.vendor }}</td>
                    <td>{{ row.action || '-' }}</td>
                    <td><span [class]="tagClass(row.buysmartAction)">{{ row.buysmartAction || 'Blank' }}</span></td>
                    <td>{{ row.queueBucket || '-' }}</td>
                    <td>{{ row.outcomeReporting }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </article>

      <aside class="panel detail">
        @if (!selected) {
          <div class="empty">Select a row to inspect trace and edit analyst fields.</div>
        } @else {
          <h2>{{ selected.caseNumber || 'Selected row' }}</h2>
          <p class="description">{{ selected.description }}</p>
          <div class="mini-grid">
            <span>DIN <strong>{{ selected.din || '-' }}</strong></span>
            <span>MIN <strong>{{ selected.min || '-' }}</strong></span>
            <span>Status <strong>{{ selected.status }}</strong></span>
          </div>

          <label class="field">
            <span>ACTION</span>
            <input [(ngModel)]="edit.action">
          </label>
          <label class="field">
            <span>If In Stock: Action</span>
            <input [(ngModel)]="edit.ifInStockAction">
          </label>
          <label class="field">
            <span>BuySmart Action</span>
            <input [(ngModel)]="edit.buysmartAction">
          </label>
          <label class="check">
            <input type="checkbox" [(ngModel)]="edit.needsReview">
            Needs review
          </label>
          <label class="field">
            <span>Analyst notes</span>
            <textarea [(ngModel)]="edit.analystNotes"></textarea>
          </label>
          <button class="button" (click)="saveSelected()">Save Row</button>

          <h3>Trace</h3>
          @if (!selected.executionTrace.length) {
            <div class="empty">No executable rule trace yet.</div>
          } @else {
            <ol class="trace-list">
              @for (trace of selected.executionTrace; track trace.runtimeRuleId) {
                <li>
                  <strong>{{ trace.runtimeRuleId }}</strong>
                  @if (trace.executionPriority !== undefined) {
                    <small>Priority {{ trace.executionPriority }}</small>
                  }
                  <span>{{ trace.description }}</span>
                </li>
              }
            </ol>
          }
        }
      </aside>
    </section>
  `,
  styles: [
    `
      .page-title {
        display: flex;
        justify-content: space-between;
        align-items: end;
        margin-bottom: var(--space-16);
      }

      .page-title p {
        margin: 0 0 var(--space-4);
        color: var(--primary-600);
        font-weight: 700;
        text-transform: uppercase;
      }

      .page-title h1 {
        margin: 0;
      }

      .filters,
      .notice,
      .table-card,
      .detail {
        padding: var(--space-16);
      }

      .notice {
        margin-bottom: var(--space-12);
      }

      .search {
        flex: 2 1 360px;
      }

      .filters .toolbar > .field {
        flex: 1 1 160px;
      }

      .workbench {
        margin-top: var(--space-16);
        grid-template-columns: minmax(0, 1fr) minmax(320px, 360px);
      }

      .table-meta {
        color: var(--muted);
        font-weight: 700;
        margin-bottom: var(--space-8);
      }

      tr.selected td {
        background: var(--secondary-50);
      }

      .detail {
        display: grid;
        gap: var(--space-12);
        align-content: start;
      }

      .detail h2,
      .detail h3 {
        margin: 0;
      }

      .description {
        margin: 0;
        color: var(--muted);
        line-height: 1.4;
      }

      .mini-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: var(--space-8);
      }

      .mini-grid span {
        display: grid;
        gap: var(--space-4);
        padding: var(--space-12);
        border-radius: var(--radius-sm);
        background: var(--neutral-50);
        color: var(--muted);
        font-size: 0.75rem;
      }

      .mini-grid strong {
        color: var(--ink);
        overflow-wrap: anywhere;
      }

      .check {
        display: flex;
        align-items: center;
        gap: var(--space-8);
        color: var(--muted);
        font-weight: 600;
      }

      .trace-list {
        display: grid;
        gap: var(--space-8);
        padding-left: 1.2rem;
        margin: 0;
      }

      .trace-list li span {
        display: block;
        color: var(--muted);
        margin-top: 0.15rem;
      }

      .trace-list li small {
        display: block;
        color: var(--muted);
        font-weight: 700;
        margin-top: var(--space-2);
      }

      @media (max-width: 1400px) {
        .workbench {
          grid-template-columns: 1fr;
        }
      }
    `
  ]
})
export class WorkbenchComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly route = inject(ActivatedRoute);
  private readonly batchSelection = inject(BatchSelectionService);
  batches: SourceBatch[] = [];
  rows: WorkflowRow[] = [];
  total = 0;
  selectedBatchId = '';
  loadingBatches = true;
  loadingRows = false;
  runningRules = false;
  message = '';
  search = '';
  needsReview = '';
  bucket = '';
  selected: WorkflowRow | null = null;
  edit: Partial<WorkflowRow> = {};
  readonly bucketOptions = [
    { id: 'auto-approved', label: 'Auto Approved' },
    { id: 'approved-1x', label: 'Approved 1X' },
    { id: 'vendor-exclusions', label: 'Vendor Exclusions' },
    { id: 'data-issues', label: 'Data Issues' },
    { id: 'denied', label: 'Denied / Cannot Add' },
    { id: 'use-right', label: 'Use Right / Conversion' },
    { id: 'find-alt', label: 'Find Alt First' },
    { id: 'cdm-review', label: 'CDM Review' },
    { id: 'compliance-review', label: 'Compliance Review' },
    { id: 'assigned-processing', label: 'Assigned for Processing' }
  ];

  ngOnInit(): void {
    void this.init();
  }

  async init(): Promise<void> {
    this.loadingBatches = true;
    try {
      this.batches = await this.api.listBatches();
      this.selectedBatchId = this.batchSelection.chooseBatch(this.batches, this.route.snapshot.queryParamMap.get('batchId') || '');
      this.bucket = this.route.snapshot.queryParamMap.get('bucket') || '';
    } finally {
      this.loadingBatches = false;
    }
    await this.loadRows();
  }

  async onBatchChange(): Promise<void> {
    this.batchSelection.save(this.selectedBatchId);
    await this.loadRows();
  }

  async loadRows(): Promise<void> {
    if (!this.selectedBatchId) return;
    this.loadingRows = true;
    this.message = '';
    const selectedRowId = this.selected?.id;
    try {
      const result = await this.api.listRows(this.selectedBatchId, {
        pageSize: 75,
        search: this.search,
        bucket: this.bucket || undefined,
        needsReview: this.needsReview || undefined
      });
      this.rows = result.rows;
      this.total = result.total;
      const nextSelected = this.rows.find((row) => row.id === selectedRowId) ?? this.rows[0] ?? null;
      this.selected = nextSelected;
      if (this.selected) this.selectRow(this.selected);
    } finally {
      this.loadingRows = false;
    }
  }

  async runRulesAndRefresh(): Promise<void> {
    if (!this.selectedBatchId) return;
    this.runningRules = true;
    this.message = '';
    try {
      const result = await this.api.runBatch(this.selectedBatchId, false);
      await this.loadRows();
      this.message = `Rules executed. ${result.run.changedRowCount} rows changed, ${result.run.reviewRowCount} rows need review.`;
    } finally {
      this.runningRules = false;
    }
  }

  selectRow(row: WorkflowRow): void {
    this.selected = row;
    this.edit = {
      action: row.action,
      ifInStockAction: row.ifInStockAction,
      buysmartAction: row.buysmartAction,
      needsReview: row.needsReview,
      analystNotes: row.analystNotes
    };
  }

  async saveSelected(): Promise<void> {
    if (!this.selected) return;
    const updated = await this.api.patchRow(this.selected.id, this.edit);
    this.rows = this.rows.map((row) => (row.id === updated.id ? updated : row));
    this.selectRow(updated);
  }

  exportExcel(): void {
    if (this.selectedBatchId) this.api.exportBatch(this.selectedBatchId, 'xlsx');
  }

  exportManualExcel(): void {
    if (this.selectedBatchId) this.api.exportBatch(this.selectedBatchId, 'manual');
  }

  tagClass(value: string): string {
    const normalized = value.toLowerCase();
    if (normalized.includes('approved')) return 'tag good';
    if (normalized.includes('denied')) return 'tag bad';
    if (normalized.includes('review')) return 'tag warn';
    return 'tag info';
  }
}
