import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom, timeout, type Observable } from 'rxjs';
import type { BatchSummary, HealthResponse, RouteManifest, RuleCreateRequest, RuleDefinition, RuleRun, SourceBatch, WorkflowRow } from '../models';

declare global {
  interface Window {
    __COMPLIANCE_API_BASE__?: string;
  }
}

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly statusTimeoutMs = 8000;
  private readonly workTimeoutMs = 120000;
  private readonly apiBase =
    typeof window !== 'undefined' && window.__COMPLIANCE_API_BASE__ ? window.__COMPLIANCE_API_BASE__.replace(/\/$/, '') : '';

  health(): Promise<HealthResponse> {
    return this.resolve(this.http.get<HealthResponse>(this.api('/api/health')));
  }

  routes(): Promise<RouteManifest> {
    return this.resolve(this.http.get<RouteManifest>(this.api('/api/routes')));
  }

  bootstrap(): Promise<{ ok: boolean; statements: number; rulesSeeded?: boolean; ruleCount?: number; executableVariantCount?: number }> {
    return this.resolve(this.http.post<{ ok: boolean; statements: number; rulesSeeded?: boolean; ruleCount?: number; executableVariantCount?: number }>(this.api('/api/bootstrap'), {}));
  }

  listBatches(): Promise<SourceBatch[]> {
    return this.resolve(this.http.get<{ batches: SourceBatch[] }>(this.api('/api/batches'))).then((res) => res.batches);
  }

  getBatch(batchId: string): Promise<SourceBatch> {
    return this.resolve(this.http.get<{ batch: SourceBatch }>(this.api(`/api/batches/${batchId}`))).then((res) => res.batch);
  }

  ingestSample(name?: string): Promise<{ batchId: string; rowCount: number; warnings: string[] }> {
    return this.resolve(this.http.post<{ batchId: string; rowCount: number; warnings: string[] }>(this.api('/api/batches/sample'), { name }), this.workTimeoutMs);
  }

  uploadWorkbook(file: File, reportingDate: string, name: string): Promise<{ batchId: string; rowCount: number; warnings: string[] }> {
    return this.fileToBase64(file).then((fileBase64) =>
      this.resolve(
        this.http.post<{ batchId: string; rowCount: number; warnings: string[] }>(this.api('/api/batches/upload'), {
          fileName: file.name,
          fileBase64,
          reportingDate,
          name
        }),
        this.workTimeoutMs
      )
    );
  }

  listRows(batchId: string, params: Record<string, string | number | boolean | undefined> = {}): Promise<{ rows: WorkflowRow[]; total: number; page: number; pageSize: number }> {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== '') query.set(key, String(value));
    });
    const qs = query.toString();
    return this.resolve(this.http.get<{ rows: WorkflowRow[]; total: number; page: number; pageSize: number }>(this.api(`/api/batches/${batchId}/rows${qs ? `?${qs}` : ''}`)));
  }

  batchSummary(batchId: string): Promise<BatchSummary> {
    return this.resolve(this.http.get<BatchSummary>(this.api(`/api/batches/${batchId}/summary`)), 30000);
  }

  patchRow(rowId: string, patch: Partial<WorkflowRow>): Promise<WorkflowRow> {
    return this.resolve(this.http.patch<{ row: WorkflowRow }>(this.api(`/api/rows/${rowId}`), patch)).then((res) => res.row);
  }

  listRules(): Promise<RuleDefinition[]> {
    return this.resolve(this.http.get<{ rules: RuleDefinition[] }>(this.api('/api/rules'))).then((res) => res.rules);
  }

  createRule(rule: RuleCreateRequest): Promise<{ rule: RuleDefinition; rules: RuleDefinition[] }> {
    return this.resolve(this.http.post<{ rule: RuleDefinition; rules: RuleDefinition[] }>(this.api('/api/rules'), rule));
  }

  updateRule(ruleId: string, rule: RuleCreateRequest): Promise<{ rule: RuleDefinition; rules: RuleDefinition[] }> {
    return this.resolve(this.http.patch<{ rule: RuleDefinition; rules: RuleDefinition[] }>(this.api(`/api/rules/${encodeURIComponent(ruleId)}`), rule));
  }

  setRuleEnabled(ruleId: string, enabled: boolean): Promise<{ rule: RuleDefinition; rules: RuleDefinition[] }> {
    return this.resolve(this.http.patch<{ rule: RuleDefinition; rules: RuleDefinition[] }>(this.api(`/api/rules/${encodeURIComponent(ruleId)}`), { enabled }));
  }

  importDefaultDaf(): Promise<{ report: Record<string, unknown>; rules: RuleDefinition[] }> {
    return this.resolve(this.http.post<{ report: Record<string, unknown>; rules: RuleDefinition[] }>(this.api('/api/rules/import-daf'), {}), this.workTimeoutMs);
  }

  seedRules(force = false): Promise<{ report: Record<string, unknown>; rules: RuleDefinition[]; seeded: boolean }> {
    return this.resolve(this.http.post<{ report: Record<string, unknown>; rules: RuleDefinition[]; seeded: boolean }>(this.api('/api/rules/seed'), { force }), this.workTimeoutMs);
  }

  importDaf(file: File): Promise<{ report: Record<string, unknown>; rules: RuleDefinition[] }> {
    return this.fileToBase64(file).then((fileBase64) =>
      this.resolve(this.http.post<{ report: Record<string, unknown>; rules: RuleDefinition[] }>(this.api('/api/rules/import-daf'), { fileName: file.name, fileBase64 }), this.workTimeoutMs)
    );
  }

  runBatch(batchId: string, dryRun = false): Promise<{ run: RuleRun; results: unknown[]; dryRun: boolean }> {
    return this.resolve(this.http.post<{ run: RuleRun; results: unknown[]; dryRun: boolean }>(this.api('/api/runs'), { batchId, mode: 'full_batch', dryRun }), this.workTimeoutMs);
  }

  exportBatch(batchId: string, format: 'csv' | 'xlsx' | 'manual'): void {
    fetch(this.api(`/api/batches/${batchId}/export`), {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ format })
    })
      .then((response) => response.blob())
      .then((blob) => {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = format === 'manual' ? `rules-engine-manual-${batchId}.xlsx` : `rules-engine-${batchId}.${format}`;
        link.click();
        URL.revokeObjectURL(url);
      });
  }

  private api(path: string): string {
    return `${this.apiBase}${path}`;
  }

  private resolve<T>(request: Observable<T>, ms = this.statusTimeoutMs): Promise<T> {
    return firstValueFrom(request.pipe(timeout({ first: ms })));
  }

  private fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(reader.error);
      reader.onload = () => resolve(String(reader.result ?? ''));
      reader.readAsDataURL(file);
    });
  }
}
