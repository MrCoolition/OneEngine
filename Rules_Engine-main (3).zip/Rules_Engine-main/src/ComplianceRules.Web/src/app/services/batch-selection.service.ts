import { Injectable } from '@angular/core';
import type { SourceBatch } from '../models';

@Injectable({ providedIn: 'root' })
export class BatchSelectionService {
  private readonly storageKey = 'complianceRules.selectedBatchId';

  chooseBatch(batches: SourceBatch[], explicitBatchId = '', preferProcessed = true): string {
    const explicit = this.validBatchId(batches, explicitBatchId);
    if (explicit) return this.save(explicit);

    const saved = this.validBatchId(batches, this.read());
    if (saved) return saved;

    const processed = preferProcessed ? batches.find((batch) => batch.status === 'processed')?.id : '';
    return this.save(processed || batches[0]?.id || '');
  }

  save(batchId: string): string {
    if (typeof localStorage !== 'undefined' && batchId) localStorage.setItem(this.storageKey, batchId);
    return batchId;
  }

  private read(): string {
    return typeof localStorage === 'undefined' ? '' : localStorage.getItem(this.storageKey) || '';
  }

  private validBatchId(batches: SourceBatch[], batchId: string | null | undefined): string {
    return batchId && batches.some((batch) => batch.id === batchId) ? batchId : '';
  }
}
