using System.Text;
using System.Text.Json.Nodes;
using ClosedXML.Excel;

public static class WorkbookParser
{
    private static readonly Dictionary<string, string> HeaderAliases = new(StringComparer.OrdinalIgnoreCase)
    {
        ["case #"] = "Case#",
        ["case"] = "Case#",
        ["subcategory"] = "Sub Category",
        ["sub category"] = "Sub Category",
        ["buy smart action"] = "Buysmart Action",
        ["buysmartaction"] = "Buysmart Action",
        ["if in-stock action"] = "If In Stock: Action",
        ["if in stock action"] = "If In Stock: Action",
        ["dstdin"] = "DSTDIN"
    };

    public static ParsedWorkbook ParseSourceWorkbook(string fileName, byte[] bytes)
    {
        using var stream = new MemoryStream(bytes);
        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheets.FirstOrDefault() ?? throw new InvalidOperationException("Source workbook has no worksheets.");
        var headers = ReadHeaderRow(worksheet, 1);
        var rows = new List<JsonObject>();
        var warnings = new List<string>();

        foreach (var row in worksheet.RowsUsed().Where(row => row.RowNumber() > 1))
        {
            var record = new JsonObject();
            var hasValue = false;
            for (var index = 0; index < headers.Count; index++)
            {
                var value = CellToJson(row.Cell(index + 1));
                if (!string.IsNullOrWhiteSpace(Normalizer.CleanText(value))) hasValue = true;
                var header = headers[index];
                if (!record.ContainsKey(header) || string.IsNullOrWhiteSpace(Normalizer.CleanText(record[header])))
                {
                    record[header] = value;
                }
            }
            if (hasValue) rows.Add(record);
        }

        if (!headers.Contains("Buysmart Action", StringComparer.OrdinalIgnoreCase))
        {
            warnings.Add("Source workbook does not include Buysmart Action; engine output will create it.");
        }

        return new ParsedWorkbook(fileName, worksheet.Name, headers, rows, warnings);
    }

    public static byte[] ExportRows(IReadOnlyList<WorkflowRow> rows, IReadOnlyList<RuleDefinition>? rules = null)
    {
        var priorityLookup = RulePriorityLookup(rules);
        using var workbook = new XLWorkbook();
        var worksheet = workbook.Worksheets.Add("Outcomes");
        var headers = ExportHeaders();
        for (var col = 0; col < headers.Length; col++) worksheet.Cell(1, col + 1).Value = headers[col];
        for (var rowIndex = 0; rowIndex < rows.Count; rowIndex++)
        {
            var row = rows[rowIndex];
            for (var col = 0; col < headers.Length; col++) worksheet.Cell(rowIndex + 2, col + 1).Value = ExportValue(row, headers[col], priorityLookup);
        }
        FormatExportSheet(worksheet);

        var ruleWorksheet = workbook.Worksheets.Add("Applied Rules");
        var ruleHeaders = AppliedRuleHeaders();
        for (var col = 0; col < ruleHeaders.Length; col++) ruleWorksheet.Cell(1, col + 1).Value = ruleHeaders[col];
        var exportRow = 2;
        foreach (var row in rows)
        {
            var traceOrder = 1;
            foreach (var trace in TraceObjects(row))
            {
                for (var col = 0; col < ruleHeaders.Length; col++)
                {
                    ruleWorksheet.Cell(exportRow, col + 1).Value = AppliedRuleValue(row, trace, traceOrder, ruleHeaders[col], priorityLookup);
                }
                traceOrder++;
                exportRow++;
            }
        }
        FormatExportSheet(ruleWorksheet);
        using var stream = new MemoryStream();
        workbook.SaveAs(stream);
        return stream.ToArray();
    }

    public static string ExportCsv(IReadOnlyList<WorkflowRow> rows, IReadOnlyList<RuleDefinition>? rules = null)
    {
        var priorityLookup = RulePriorityLookup(rules);
        var headers = ExportHeaders();
        var builder = new StringBuilder();
        builder.AppendLine(string.Join(',', headers));
        foreach (var row in rows)
        {
            builder.AppendLine(string.Join(',', headers.Select(header => CsvCell(ExportValue(row, header, priorityLookup)))));
        }
        return builder.ToString();
    }

    private static List<string> ReadHeaderRow(IXLWorksheet worksheet, int rowNumber)
    {
        var row = worksheet.Row(rowNumber);
        var lastCell = Math.Max(row.LastCellUsed()?.Address.ColumnNumber ?? 0, worksheet.LastColumnUsed()?.ColumnNumber() ?? 0);
        var headers = new List<string>();
        for (var col = 1; col <= lastCell; col++)
        {
            var header = CanonicalHeader(Normalizer.CleanText(CellToJson(row.Cell(col))));
            headers.Add(string.IsNullOrWhiteSpace(header) ? $"Column {col}" : header);
        }
        return headers;
    }

    private static string CanonicalHeader(string header)
    {
        var raw = string.Join(' ', header.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries));
        var key = raw.ToLowerInvariant().Replace("_", " ").Replace("-", " ").Trim();
        return HeaderAliases.TryGetValue(key, out var alias) ? alias : raw;
    }

    private static JsonNode? CellToJson(IXLCell cell)
    {
        if (cell.IsEmpty()) return "";
        if (cell.DataType == XLDataType.Boolean) return cell.GetBoolean();
        if (cell.DataType == XLDataType.Number)
        {
            return cell.TryGetValue<DateTime>(out var date) && cell.Style.DateFormat.Format.Length > 0
                ? date.ToString("O")
                : cell.GetDouble();
        }
        if (cell.DataType == XLDataType.DateTime) return cell.GetDateTime().ToString("O");
        return cell.GetFormattedString();
    }

    private static string[] ExportHeaders() =>
    [
        "Business",
        "Type",
        "Case#",
        "Vendor",
        "DIN",
        "MIN",
        "Description",
        "ACTION",
        "If In Stock: Action",
        "Buysmart Action",
        "Assigned Bucket",
        "Rule Applied",
        "Applied Rule Count",
        "Applied Rule Priorities",
        "Applied Rule Actions",
        "Applied Rule Details",
        "Needs Review",
        "Validation Status",
        "Excluded",
        "Excluded Reason",
        "Compliance Bucket",
        "Outcome Reporting",
        "Analyst Notes"
    ];

    private static string ExportValue(WorkflowRow row, string header, IReadOnlyDictionary<string, int> priorityLookup) => header switch
    {
        "Business" => row.Business,
        "Type" => row.RequestType,
        "Case#" => row.CaseNumber,
        "Vendor" => row.Vendor,
        "DIN" => row.Din,
        "MIN" => row.Min,
        "Description" => row.Description,
        "ACTION" => row.Action,
        "If In Stock: Action" => row.IfInStockAction,
        "Buysmart Action" => row.BuysmartAction,
        "Assigned Bucket" => RuleEngine.BucketForRow(row).Label,
        "Rule Applied" => row.RuleApplied,
        "Applied Rule Count" => TraceObjects(row).Count().ToString(),
        "Applied Rule Priorities" => string.Join("; ", TraceObjects(row).Select(trace => TracePriority(trace, priorityLookup)).Where(value => !string.IsNullOrWhiteSpace(value))),
        "Applied Rule Actions" => string.Join('\n', TraceObjects(row).Select(trace => $"{FirstText(TraceValue(trace, "runtimeRuleId"), TraceValue(trace, "ruleId"))}: {FirstText(TraceValue(trace, "actionSummary"), "Matched")}")),
        "Applied Rule Details" => string.Join('\n', TraceObjects(row).Select(trace => RuleTraceDetail(trace, priorityLookup))),
        "Needs Review" => row.NeedsReview ? "TRUE" : "FALSE",
        "Validation Status" => row.ValidationStatus,
        "Excluded" => row.Excluded ? "TRUE" : "FALSE",
        "Excluded Reason" => row.ExcludedReason,
        "Compliance Bucket" => RuleEngine.BucketForRow(row).Label,
        "Outcome Reporting" => row.OutcomeReporting,
        "Analyst Notes" => row.AnalystNotes,
        _ => ""
    };

    private static string[] AppliedRuleHeaders() =>
    [
        "Source Row",
        "Case#",
        "Business",
        "Type",
        "Vendor",
        "DIN",
        "MIN",
        "Description",
        "Trace Order",
        "Rule Priority",
        "Rule ID",
        "Runtime Rule ID",
        "Runtime Kind",
        "Rule Description",
        "Associated Rule Action",
        "Matched At",
        "Final ACTION",
        "Final If In Stock: Action",
        "Final Buysmart Action",
        "Compliance Bucket",
        "Outcome Reporting",
        "Needs Review",
        "Excluded",
        "Excluded Reason"
    ];

    private static string AppliedRuleValue(WorkflowRow row, JsonObject trace, int traceOrder, string header, IReadOnlyDictionary<string, int> priorityLookup) => header switch
    {
        "Source Row" => row.SourceRowNumber.ToString(),
        "Case#" => row.CaseNumber,
        "Business" => row.Business,
        "Type" => row.RequestType,
        "Vendor" => row.Vendor,
        "DIN" => row.Din,
        "MIN" => row.Min,
        "Description" => row.Description,
        "Trace Order" => traceOrder.ToString(),
        "Rule Priority" => TracePriority(trace, priorityLookup),
        "Rule ID" => TraceValue(trace, "ruleId"),
        "Runtime Rule ID" => TraceValue(trace, "runtimeRuleId"),
        "Runtime Kind" => TraceValue(trace, "runtimeKind"),
        "Rule Description" => TraceValue(trace, "description"),
        "Associated Rule Action" => TraceValue(trace, "actionSummary"),
        "Matched At" => TraceValue(trace, "matchedAt"),
        "Final ACTION" => row.Action,
        "Final If In Stock: Action" => row.IfInStockAction,
        "Final Buysmart Action" => row.BuysmartAction,
        "Compliance Bucket" => RuleEngine.BucketForRow(row).Label,
        "Outcome Reporting" => row.OutcomeReporting,
        "Needs Review" => row.NeedsReview ? "TRUE" : "FALSE",
        "Excluded" => row.Excluded ? "TRUE" : "FALSE",
        "Excluded Reason" => row.ExcludedReason,
        _ => ""
    };

    private static string RuleTraceDetail(JsonObject trace, IReadOnlyDictionary<string, int> priorityLookup)
    {
        var resolvedPriority = TracePriority(trace, priorityLookup);
        var priority = string.IsNullOrWhiteSpace(resolvedPriority) ? "No priority" : $"Priority {resolvedPriority}";
        var runtimeRuleId = FirstText(TraceValue(trace, "runtimeRuleId"), TraceValue(trace, "ruleId"), "Unknown rule");
        var runtimeKind = TraceValue(trace, "runtimeKind");
        var description = TraceValue(trace, "description");
        var actionSummary = TraceValue(trace, "actionSummary");
        return $"{priority} {runtimeRuleId}{(string.IsNullOrWhiteSpace(runtimeKind) ? "" : $" {runtimeKind}")}{(string.IsNullOrWhiteSpace(description) ? "" : $" - {description}")}{(string.IsNullOrWhiteSpace(actionSummary) ? "" : $" => {actionSummary}")}";
    }

    private static IEnumerable<JsonObject> TraceObjects(WorkflowRow row) => row.ExecutionTrace.OfType<JsonObject>();

    private static string TraceValue(JsonObject trace, string key) => NodeText(trace[key]);

    private static string TracePriority(JsonObject trace, IReadOnlyDictionary<string, int> priorityLookup)
    {
        var explicitPriority = TraceValue(trace, "executionPriority");
        if (!string.IsNullOrWhiteSpace(explicitPriority)) return explicitPriority;
        var runtimeRuleId = TraceValue(trace, "runtimeRuleId");
        if (!string.IsNullOrWhiteSpace(runtimeRuleId) && priorityLookup.TryGetValue(runtimeRuleId, out var runtimePriority)) return runtimePriority.ToString();
        var ruleId = TraceValue(trace, "ruleId");
        return !string.IsNullOrWhiteSpace(ruleId) && priorityLookup.TryGetValue(ruleId, out var rulePriority) ? rulePriority.ToString() : "";
    }

    private static Dictionary<string, int> RulePriorityLookup(IReadOnlyList<RuleDefinition>? rules)
    {
        var lookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (var rule in rules ?? [])
        {
            var firstPriority = rule.Variants.Select(variant => variant.ExecutionPriority).DefaultIfEmpty().Where(priority => priority > 0).DefaultIfEmpty().Min();
            if (firstPriority > 0) lookup[rule.RuleId] = firstPriority;
            foreach (var variant in rule.Variants)
            {
                if (!string.IsNullOrWhiteSpace(variant.RuntimeRuleId)) lookup[variant.RuntimeRuleId] = variant.ExecutionPriority;
            }
        }
        return lookup;
    }

    private static string NodeText(JsonNode? node)
    {
        if (node is null) return "";
        if (node is JsonValue value)
        {
            if (value.TryGetValue<string>(out var text)) return text;
            if (value.TryGetValue<int>(out var integer)) return integer.ToString();
            if (value.TryGetValue<long>(out var longValue)) return longValue.ToString();
            if (value.TryGetValue<decimal>(out var decimalValue)) return decimalValue.ToString();
            if (value.TryGetValue<double>(out var doubleValue)) return doubleValue.ToString();
            if (value.TryGetValue<bool>(out var boolValue)) return boolValue ? "TRUE" : "FALSE";
        }
        return node.ToJsonString();
    }

    private static string FirstText(params string[] values) => values.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value)) ?? "";

    private static void FormatExportSheet(IXLWorksheet worksheet)
    {
        worksheet.Row(1).Style.Font.Bold = true;
        worksheet.SheetView.FreezeRows(1);
        worksheet.Columns().AdjustToContents(14, 44);
    }

    private static string CsvCell(string value)
    {
        if (!value.Contains(',') && !value.Contains('"') && !value.Contains('\n')) return value;
        return $"\"{value.Replace("\"", "\"\"")}\"";
    }
}
